import Foundation
@testable import JiuzhangShellCore

private func eventLifecycleSourceSlice(
  _ source: String,
  from start: String,
  through end: String
) -> String? {
  guard
    let startRange = source.range(of: start),
    let endRange = source.range(
      of: end,
      range: startRange.upperBound..<source.endIndex
    )
  else { return nil }
  return String(source[startRange.lowerBound..<endRange.lowerBound])
}

private func appearsInOrder(_ source: String, _ values: [String]) -> Bool {
  var lowerBound = source.startIndex
  for value in values {
    guard let range = source.range(of: value, range: lowerBound..<source.endIndex) else {
      return false
    }
    lowerBound = range.upperBound
  }
  return true
}

func runArkEventPumpLifecycleContractChecks() async {
  let stoppedPump = ArkEventPump(
    baseURL: URL(string: "http://127.0.0.1:1")!,
    apiToken: "lifecycle-contract"
  )
  async let firstStop: Void = stoppedPump.stop()
  async let secondStop: Void = stoppedPump.stop()
  _ = await (firstStop, secondStop)
  await stoppedPump.start()
  let stoppedEvent = await stoppedPump.nextEvent()
  check(
    stoppedEvent == nil,
    "native event pump stop is idempotent, terminal, and finishes its stream"
  )

  let activePump = ArkEventPump(
    baseURL: URL(string: "http://127.0.0.1:1")!,
    apiToken: "active-lifecycle-contract"
  )
  await activePump.start()
  await Task.yield()
  async let firstActiveStop: Void = activePump.stop()
  async let secondActiveStop: Void = activePump.stop()
  _ = await (firstActiveStop, secondActiveStop)
  await activePump.start()
  let activeStoppedEvent = await activePump.nextEvent()
  check(
    activeStoppedEvent == nil,
    "active event pump concurrent stop callers reach one terminal stream"
  )

  let mailbox = ArkEventMailbox<Int>(capacity: 2)
  let firstAccepted = await mailbox.send(1)
  let secondAccepted = await mailbox.send(2)
  check(firstAccepted, "bounded mailbox accepts its first event")
  check(secondAccepted, "bounded mailbox accepts up to capacity")
  let thirdSend = Task { await mailbox.send(3) }
  try? await Task.sleep(nanoseconds: 20_000_000)
  let fullCounts = await mailbox.counts()
  check(
    fullCounts.buffered == 2 && fullCounts.waitingProducers == 1,
    "bounded mailbox suspends rather than dropping a producer at capacity"
  )
  let firstEvent = await mailbox.next()
  let thirdAccepted = await thirdSend.value
  check(firstEvent == 1, "bounded mailbox preserves FIFO order")
  check(thirdAccepted, "waiting producer resumes when the consumer frees capacity")
  let secondEvent = await mailbox.next()
  let thirdEvent = await mailbox.next()
  check(secondEvent == 2 && thirdEvent == 3, "bounded mailbox delivers every event")
  await mailbox.finish()
  let finishedEvent = await mailbox.next()
  check(finishedEvent == nil, "bounded mailbox finish wakes and terminates the consumer")

  let pumpURL = contractNativeRoot.appendingPathComponent(
    "Sources/JiuzhangShellCore/ArkEventPump.swift"
  )
  let modelURL = contractNativeRoot.appendingPathComponent(
    "Sources/JiuzhangShellUI/ArkAppModel.swift"
  )
  let delegateURL = contractNativeRoot.appendingPathComponent(
    "Sources/JiuzhangShell/AppDelegate.swift"
  )
  guard
    let pump = try? String(contentsOf: pumpURL, encoding: .utf8),
    let model = try? String(contentsOf: modelURL, encoding: .utf8),
    let delegate = try? String(contentsOf: delegateURL, encoding: .utf8),
    let pumpStop = eventLifecycleSourceSlice(
      pump,
      from: "public func stop() async",
      through: "private func run(channel: ArkEventChannel) async"
    ),
    let modelStart = eventLifecycleSourceSlice(
      model,
      from: "public func start()",
      through: "public func shutdown() async"
    ),
    let modelShutdown = eventLifecycleSourceSlice(
      model,
      from: "public func shutdown() async",
      through: "public func refreshNavigation(refreshWiki: Bool = true) async"
    ),
    let appTermination = eventLifecycleSourceSlice(
      delegate,
      from: "func applicationShouldTerminate(",
      through: "@objc func showArkSettings"
    ),
    let interfaceShutdown = eventLifecycleSourceSlice(
      delegate,
      from: "private func shutdownNativeInterface() async",
      through: "private func showStarting()"
    )
  else {
    check(false, "native event lifecycle sources are readable for shutdown ownership checks")
    return
  }

  let teardownOwnerInstall = pumpStop
    .components(separatedBy: "lifecycle = .stopping")
    .last?
    .components(separatedBy: "let stopTask = Task {")
    .first ?? ""
  check(
    pumpStop.contains("if let stopTask")
      && pumpStop.components(separatedBy: "let stopTask = Task {").count == 2
      && !teardownOwnerInstall.contains("await ")
      && appearsInOrder(pumpStop, [
        "lifecycle = .stopping",
        "socket.cancel(with: .goingAway, reason: nil)",
        "pump.cancel()",
        "let stopTask = Task {",
        "await mailbox.finish()",
        "await pump.value",
        "self.stopTask = stopTask",
        "await stopTask.value",
        "lifecycle = .stopped",
      ]),
    "event pump concurrent stop callers share one socket and pump quiescence operation"
  )
  check(
    modelStart.contains("guard eventLifecycle == .idle else { return }")
      && modelStart.contains("while !Task.isCancelled, let frame = await eventPump.nextEvent()"),
    "app model starts one event consumer and refuses a second lifecycle"
  )
  check(
    modelShutdown.contains("if let eventShutdownTask")
      && appearsInOrder(modelShutdown, [
        "consumer?.cancel()",
        "await eventPump.stop()",
        "await consumer.value",
        "eventLifecycle = .stopped",
      ]),
    "app model cancels event delivery and awaits pump and consumer quiescence"
  )
  check(
    appearsInOrder(appTermination, [
      "if let error = await shutdownNativeInterface()",
      "presentDraftFlushFailure(error)",
      "sender.reply(toApplicationShouldTerminate: false)",
      "backend.stop",
      "sender.reply(toApplicationShouldTerminate: true)",
    ]),
    "application termination vetoes a failed draft flush and stops the native lifecycle before the backend"
  )
  check(
    appearsInOrder(interfaceShutdown, [
      "await workbenchDraftFlushCoordinator.flush()",
      "await model.shutdown()",
      "await workbenchDraftFlushCoordinator.flush()",
      "hostingView?.removeFromSuperview()",
      "appModel = nil",
    ])
      && delegate.components(separatedBy: "appModel = nil").count == 2
      && delegate.contains("await self.shutdownNativeInterface()")
      && delegate.contains("guard let self, !self.requestedTermination,")
      && delegate.contains("guard !requestedTermination, backend.isRunning,"),
    "backend restart awaits the single model shutdown owner before discarding the interface"
  )
}
