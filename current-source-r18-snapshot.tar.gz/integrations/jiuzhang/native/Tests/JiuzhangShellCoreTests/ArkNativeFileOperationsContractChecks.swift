import Foundation
@testable import JiuzhangShellUI

func runArkNativeFileOperationsContractChecks() {
  let fileManager = FileManager.default
  let home = fileManager.temporaryDirectory
    .appendingPathComponent("ark-file-ops-\(UUID().uuidString)", isDirectory: true)
  let root = home.appendingPathComponent("workspace", isDirectory: true)
  let outside = home.appendingPathComponent("outside", isDirectory: true)
  try? fileManager.createDirectory(at: root, withIntermediateDirectories: true)
  try? fileManager.createDirectory(at: outside, withIntermediateDirectories: true)
  defer { try? fileManager.removeItem(at: home) }

  guard let access = try? NativeWorkspaceAccess(rootURL: root) else {
    check(false, "native file operations open a confined temporary workspace")
    return
  }

  do {
    let sourceFolder = try access.createFolder(named: "source", in: root)
    let sourceFile = try access.createFile(named: "draft.txt", in: sourceFolder)
    try access.atomicWrite("hello\n", to: sourceFile, expectedText: "")
    let duplicate = try access.duplicateItem(sourceFile)
    let renamed = try access.renameItem(duplicate, to: "renamed.txt")
    let destination = try access.createFolder(named: "destination", in: root)
    let moved = try access.moveItem(renamed, to: destination)
    check(
      moved.lastPathComponent == "renamed.txt"
        && (try? access.readUTF8Text(at: moved)) == "hello\n"
        && !fileManager.fileExists(atPath: renamed.path),
      "native file operations create, atomically save, duplicate, rename, and move inside the root"
    )
  } catch {
    check(false, "native file operations create/duplicate/rename/move: \(error)")
  }

  do {
    _ = try access.createFolder(named: "destination", in: root)
    check(false, "native file operations reject an existing destination")
  } catch NativeWorkbenchError.itemAlreadyExists {
    check(true, "native file operations reject an existing destination")
  } catch {
    check(false, "native file operations reject an existing destination: \(error)")
  }

  do {
    _ = try access.createFile(named: "../escape.txt", in: root)
    check(false, "native file operations reject path-shaped leaf names")
  } catch NativeWorkbenchError.invalidItemName {
    check(true, "native file operations reject path-shaped leaf names")
  } catch {
    check(false, "native file operations reject path-shaped leaf names: \(error)")
  }

  do {
    _ = try access.createFile(named: "outside.txt", in: outside)
    check(false, "native file operations reject destination directories outside the root")
  } catch NativeWorkbenchError.pathOutsideRoot {
    check(true, "native file operations reject destination directories outside the root")
  } catch {
    check(false, "native file operations reject destination directories outside the root: \(error)")
  }

  do {
    _ = try access.createFile(named: ".DS_Store", in: root)
    _ = try access.createFile(named: ".localized", in: root)
    let ordinary = try access.listDirectory(root, showHiddenNoise: false).map(\.name)
    let explicit = try access.listDirectory(root, showHiddenNoise: true).map(\.name)
    if ordinary.contains(".DS_Store")
      || ordinary.contains(".localized")
      || !explicit.contains(".DS_Store")
      || !explicit.contains(".localized") {
      print("FILE NOISE DIAGNOSTIC ordinary=\(ordinary) explicit=\(explicit)")
    }
    check(
      !ordinary.contains(".DS_Store")
        && !ordinary.contains(".localized")
        && explicit.contains(".DS_Store")
        && explicit.contains(".localized"),
      "native file tree hides system noise by default and reveals it explicitly"
    )
  } catch {
    check(false, "native file hidden-noise behavior: \(error)")
  }

  let outsideFile = outside.appendingPathComponent("outside.txt")
  try? "outside".write(to: outsideFile, atomically: true, encoding: .utf8)
  let link = root.appendingPathComponent("outside-link")
  try? fileManager.createSymbolicLink(at: link, withDestinationURL: outsideFile)
  let listedNames = (try? access.listDirectory(root, showHiddenNoise: true).map(\.name)) ?? []
  check(
    !listedNames.contains("outside-link") && (try? access.readUTF8Text(at: link)) == nil,
    "native file operations neither display nor follow a symlink escape"
  )

  let routedFile = root.appendingPathComponent("routed.txt")
  try? "routed".write(to: routedFile, atomically: true, encoding: .utf8)
  check(
    (try? access.validatedRegularFileURL(routedFile)) == routedFile.standardizedFileURL,
    "native transcript file routing admits an ordinary file under the exact workspace root"
  )
  check(
    (try? access.validatedRegularFileURL(outsideFile)) == nil
      && (try? access.validatedRegularFileURL(link)) == nil
      && (try? access.validatedRegularFileURL(root)) == nil,
    "native transcript file routing rejects outside paths, symlinks, and directories"
  )
}
