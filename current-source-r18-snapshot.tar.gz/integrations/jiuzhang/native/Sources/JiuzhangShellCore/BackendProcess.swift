import Darwin
import Foundation

/// Error thrown by {@link BackendProcess.start} when a previous process has
/// not been reaped yet.
public enum BackendProcessError: Error {
  case alreadyRunning
}

/// Wraps one backend launch. Each {@link start} creates a fresh Foundation
/// `Process` and output `Pipe`, because a `Process` cannot be re-run
/// after termination; the shell restarts the backend after an unexpected
/// exit, so no launch may reuse another launch's objects. The old process's
/// termination handler clears only its own pipe and reports only its own
/// exit and stop completion.
public final class BackendProcess {
  private let lock = NSLock()
  private var process: Process?
  private var output: Pipe?
  private var bufferedOutput = Data()
  private var stopCompletion: (() -> Void)?

  /// Receives every output line the child writes (stdout and stderr merged).
  public var onLine: ((String) -> Void)?
  /// Receives the child's termination status after it exits, on the main queue.
  public var onExit: ((Int32) -> Void)?

  public init() {}

  /// Whether a process is currently running.
  public var isRunning: Bool {
    lock.lock()
    defer { lock.unlock() }
    return process?.isRunning ?? false
  }

  /// Process identifier of the running process, or nil when none is running.
  public var processIdentifier: pid_t? {
    lock.lock()
    defer { lock.unlock() }
    return process?.processIdentifier
  }

  /// Start a fresh backend process with its own pipe.
  /// - Throws: `BackendProcessError.alreadyRunning` when the previous
  /// process has not been reaped yet, or the launch error from `Process.run`.
  public func start(
    executable: String,
    arguments: [String],
    environment: [String: String],
    workingDirectory: URL
  ) throws {
    lock.lock()
    guard process == nil else {
      lock.unlock()
      throw BackendProcessError.alreadyRunning
    }
    let process = Process()
    let output = Pipe()
    self.process = process
    self.output = output
    lock.unlock()

    process.executableURL = URL(fileURLWithPath: executable)
    process.arguments = arguments
    process.environment = environment
    process.currentDirectoryURL = workingDirectory
    process.standardOutput = output
    process.standardError = output

    output.fileHandleForReading.readabilityHandler = { [weak self] handle in
      guard let self else { return }
      let data = handle.availableData
      guard !data.isEmpty else { return }
      self.consume(data)
    }
    process.terminationHandler = { [weak self, weak output] terminated in
      DispatchQueue.main.async {
        guard let self, let output else { return }
        output.fileHandleForReading.readabilityHandler = nil
        self.flushBufferedOutput()
        // Clear the ownership slot before notifying observers. The observer
        // is allowed to start a replacement after it receives the exit signal;
        // clearing it afterwards races that recovery path into
        // `alreadyRunning`.
        let stopCompletion: (() -> Void)?
        self.lock.lock()
        if self.process === terminated {
          self.process = nil
          self.output = nil
        }
        stopCompletion = self.stopCompletion
        self.stopCompletion = nil
        self.lock.unlock()
        self.onExit?(terminated.terminationStatus)
        stopCompletion?()
      }
    }

    do {
      try process.run()
    } catch {
      lock.lock()
      if self.process === process {
        self.process = nil
      }
      lock.unlock()
      throw error
    }
  }

  /// Terminate the running launcher, force-killing it after seven seconds, and
  /// invoke `completion` once the termination handler has reaped it. When
  /// nothing is running, `completion` runs immediately. The launcher's own
  /// four-second child deadline must settle first so the UI never kills its
  /// supervisor while leaving the backend child alive.
  public func stop(completion: @escaping () -> Void) {
    lock.lock()
    guard let process = process, process.isRunning else {
      lock.unlock()
      completion()
      return
    }
    stopCompletion = completion
    lock.unlock()
    process.terminate()

    let pid = process.processIdentifier
    DispatchQueue.global().asyncAfter(deadline: .now() + 7) { [weak process] in
      guard let process, process.isRunning else { return }
      Darwin.kill(pid, SIGKILL)
    }
  }

  private func consume(_ data: Data) {
    lock.lock()
    bufferedOutput.append(data)
    var lines: [String] = []
    while let newline = bufferedOutput.firstIndex(of: 0x0A) {
      let lineData = bufferedOutput[..<newline]
      bufferedOutput.removeSubrange(...newline)
      if let line = String(data: lineData, encoding: .utf8) {
        lines.append(line)
      }
    }
    lock.unlock()

    for line in lines {
      DispatchQueue.main.async { [weak self] in
        self?.onLine?(line)
      }
    }
  }

  private func flushBufferedOutput() {
    lock.lock()
    let data = bufferedOutput
    bufferedOutput.removeAll(keepingCapacity: false)
    lock.unlock()
    guard !data.isEmpty, let line = String(data: data, encoding: .utf8) else { return }
    onLine?(line)
  }
}
