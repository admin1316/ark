import Foundation

/// Fixed startup rules for the native Jiuzhang desktop application.
public enum JiuzhangShellContract {
  public static let loopbackHost = "127.0.0.1"

  /// Return the isolated Harness home used by the desktop product.
  public static func defaultHarnessHome(fileManager: FileManager = .default) -> URL {
    fileManager.homeDirectoryForCurrentUser
      .appendingPathComponent("Library", isDirectory: true)
      .appendingPathComponent("Application Support", isDirectory: true)
      .appendingPathComponent("Ark", isDirectory: true)
      .appendingPathComponent("Harness", isDirectory: true)
  }

  /// Return Ark's product-owned knowledge project.  It deliberately lives
  /// outside the source checkout so the desktop app never treats its own
  /// repository as user knowledge or as a Workspace.
  public static func defaultKnowledgeRoot(fileManager: FileManager = .default) -> URL {
    fileManager.homeDirectoryForCurrentUser
      .appendingPathComponent("Library", isDirectory: true)
      .appendingPathComponent("Application Support", isDirectory: true)
      .appendingPathComponent("Ark", isDirectory: true)
      .appendingPathComponent("Knowledge", isDirectory: true)
  }

  public static func defaultWikiRoot(fileManager: FileManager = .default) -> URL {
    defaultKnowledgeRoot(fileManager: fileManager)
      .appendingPathComponent("wiki", isDirectory: true)
  }

  /// Safe cwd for chats created before the user connects a Workspace.  It is
  /// deliberately separate from the source checkout, the installed app bundle,
  /// runtime payloads, Harness state, and the canonical knowledge project.
  public static func defaultSessionWorkspace(fileManager: FileManager = .default) -> URL {
    fileManager.homeDirectoryForCurrentUser
      .appendingPathComponent("Library", isDirectory: true)
      .appendingPathComponent("Application Support", isDirectory: true)
      .appendingPathComponent("Ark", isDirectory: true)
      .appendingPathComponent("Default Workspace", isDirectory: true)
  }

  /// Reject the installed Ark product itself or product-owned data. The source
  /// checkout remains eligible as an explicit maintenance Workspace.
  public static func protectedWorkspaceReason(
    path: String,
    bundle: Bundle = .main,
    fileManager: FileManager = .default
  ) -> String? {
    let candidate = URL(fileURLWithPath: path, isDirectory: true)
      .standardizedFileURL.resolvingSymlinksInPath().path
    let productData = fileManager.homeDirectoryForCurrentUser
      .appendingPathComponent("Library/Application Support/Ark", isDirectory: true)
      .standardizedFileURL.resolvingSymlinksInPath().path
    let installedBundle = bundle.bundleURL.standardizedFileURL.resolvingSymlinksInPath().path
    let canonicalInstalledBundle = "/Applications/Ark.app"
    var protected: [(String, String)] = [
      (canonicalInstalledBundle, "Ark 应用与内嵌 runtime"),
      (productData, "Ark 产品数据目录"),
    ]
    if bundle.bundleURL.pathExtension.lowercased() == "app",
       installedBundle != canonicalInstalledBundle {
      protected.append((installedBundle, "Ark 应用与内嵌 runtime"))
    }
    for (root, label) in protected {
      if candidate == root
        || candidate.hasPrefix(root + "/")
        || root.hasPrefix(candidate + "/")
      {
        return "不能把\(label)加入工作区"
      }
    }
    return nil
  }

  /// Return the launcher arguments that request an OS-assigned loopback port.
  /// The native client learns the actual origin from the authenticated readiness line,
  /// so Ark has no browser-origin reason to contend for a fixed desktop port.
  /// `--parent-pid` hands the launcher the UI's own pid so it exits its backend
  /// child when the UI disappears (crash or termination), instead of orphaning.
  public static func launchArguments(launcherPath: String) -> [String] {
    [
      launcherPath,
      "--parent-pid", String(ProcessInfo.processInfo.processIdentifier),
      "--port", "0",
    ]
  }

  /// Resolve a recorded path to an absolute path: absolute values pass through,
  /// and "Contents/..." values resolve against the application bundle (the
  /// self-contained layout embedded by build-app.sh).
  public static func resolveBundlePath(_ recorded: String, bundle: Bundle = .main) -> String {
    if recorded.hasPrefix("/") { return recorded }
    return bundle.bundleURL.appendingPathComponent(recorded).path
  }

  /// Return whether the recorded Node, launcher, runner, and runtime paths form a usable source or standalone installation.
  /// - Parameters:
  ///   - nodeExecutable: Absolute Node.js executable selected at build time.
  ///   - launcherPath: Absolute Jiuzhang launcher path recorded in the application bundle.
  ///   - runnerPath: Absolute Native API runner path recorded for startup validation.
  ///   - runtimeRoot: Absolute ordinary directory used as the child working directory.
  ///   - fileManager: File manager used to inspect the recorded paths.
  /// - Returns: `true` when every path exists with the required access and matches one supported runtime layout.
  public static func runtimePathsAreUsable(
    nodeExecutable: String,
    launcherPath: String,
    runnerPath: String,
    runtimeRoot: String,
    fileManager: FileManager = .default
  ) -> Bool {
    guard
      nodeExecutable.hasPrefix("/"),
      launcherPath.hasPrefix("/"),
      runnerPath.hasPrefix("/"),
      runtimeRoot.hasPrefix("/"),
      fileManager.isExecutableFile(atPath: nodeExecutable),
      fileManager.isReadableFile(atPath: launcherPath),
      fileManager.isReadableFile(atPath: runnerPath),
      ordinaryDirectoryExists(atPath: runtimeRoot, fileManager: fileManager)
    else {
      return false
    }

    let root = URL(fileURLWithPath: runtimeRoot, isDirectory: true).standardizedFileURL
    let launcher = URL(fileURLWithPath: launcherPath).standardizedFileURL
    let runner = URL(fileURLWithPath: runnerPath).standardizedFileURL
    let standaloneLayout = (
      launcher == root.appendingPathComponent("start.mjs")
        && runner == root.appendingPathComponent(
          "node_modules/@deepseek-ai/dsh-native-api-runner/lib/bin.js"
        )
    )
    let sourceLayout = (
      launcher == root.appendingPathComponent("integrations/jiuzhang/src/start.mjs")
        && runner == root.appendingPathComponent("packages/boot/native-api-runner/lib/bin.js")
    )
    return standaloneLayout || sourceLayout
  }

  /// Build the child environment without sharing the default `~/.dsh` state.
  /// - Parameters:
  ///   - base: Parent process environment; only the fixed non-secret allowlist is retained.
  ///   - harnessHome: Product-owned data directory.
  ///   - apiToken: Non-empty launch token shared only with the native API client.
  /// - Returns: The isolated child environment.
  public static func childEnvironment(
    base: [String: String],
    harnessHome: URL,
    apiToken: String
  ) -> [String: String] {
    precondition(!apiToken.isEmpty, "Ark API token must not be empty")
    let retainedNames = [
      "HOME", "PATH", "TMPDIR", "LANG", "LC_ALL", "LC_CTYPE", "SHELL", "USER", "LOGNAME",
    ]
    var environment = base.filter { retainedNames.contains($0.key) }
    environment["JIUZHANG_DSH_HOME"] = harnessHome.path
    environment["DSH_HOME"] = harnessHome.path
    environment["DSH_PERMISSION_MODE"] = "read-only"
    environment["DSH_TELEMETRY_DISABLED"] = "1"
    environment["DSH_API_TOKEN"] = apiToken
    let knowledgeRoot = defaultKnowledgeRoot()
    environment["ARK_MAIN_ROOT"] = knowledgeRoot.path
    environment["ARK_WIKI_ROOT"] = defaultWikiRoot().path
    environment["ARK_DEFAULT_WORKSPACE"] = defaultSessionWorkspace().path
    return environment
  }

  /// Parse the internal service readiness line emitted after the API listener binds.
  public static func readinessURL(from line: String) -> URL? {
    let prefix = "dsh native-api: "
    let normalized = line.trimmingCharacters(in: .whitespacesAndNewlines)
    guard normalized.hasPrefix(prefix) else { return nil }

    let rawURL = String(normalized.dropFirst(prefix.count))
    guard
      let components = URLComponents(string: rawURL),
      components.scheme == "http",
      components.host == loopbackHost,
      components.user == nil,
      components.password == nil,
      components.path.isEmpty,
      components.query == nil,
      components.fragment == nil,
      let port = components.port,
      (1...65_535).contains(port),
      let url = components.url
    else {
      return nil
    }
    return url
  }

  private static func ordinaryDirectoryExists(
    atPath path: String,
    fileManager: FileManager
  ) -> Bool {
    guard let attributes = try? fileManager.attributesOfItem(atPath: path) else { return false }
    return attributes[.type] as? FileAttributeType == .typeDirectory
  }
}
