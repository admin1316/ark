import { createHash, randomBytes } from 'node:crypto'
import { copyFile, mkdir, readFile, rename, rm, writeFile } from 'node:fs/promises'
import { spawnSync } from 'node:child_process'
import { isAbsolute, join, relative, resolve } from 'node:path'
import { tmpdir } from 'node:os'
import { parseArgs } from 'node:util'
import { fileURLToPath } from 'node:url'
import { createArkRuntimePlan, runtimeAssetSource } from './runtime-plan.mjs'
import { assertJavaScriptModuleSyntax, packageJavaScriptEntries } from './runtime-closure.mjs'

function run(command, args, cwd) {
  const result = spawnSync(command, args, { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] })
  if (result.status !== 0) {
    const detail = [result.stdout, result.stderr].filter(Boolean).join('\n').trim()
    throw new Error(`${command} ${args.join(' ')} failed with ${String(result.status)}${detail === '' ? '' : `\n${detail}`}`)
  }
}

function capture(command, args, cwd) {
  const result = spawnSync(command, args, { cwd, encoding: 'utf8', stdio: ['ignore', 'pipe', 'pipe'] })
  if (result.status !== 0) {
    throw new Error(`${command} ${args.join(' ')} failed with ${String(result.status)}\n${result.stderr.trim()}`)
  }
  return result.stdout
}

function packedMember(tarball, member, repositoryRoot) {
  return capture('tar', ['-xOzf', tarball, member], repositoryRoot)
}

function tarballName(entry) {
  const unscoped = entry.name.startsWith('@') ? entry.name.slice(1).replace('/', '-') : entry.name
  return `${unscoped}-${entry.version}.tgz`
}

function tarballGroup(directory) {
  if (directory.startsWith('vendor/')) return 'vendor'
  if (directory.startsWith('native/')) return 'native'
  return 'dsh'
}

function assertSafeOutput(repositoryRoot, output) {
  if (!isAbsolute(output)) throw new Error('Ark runtime pack output must be absolute')
  const destination = resolve(output)
  if (destination === '/' || destination === repositoryRoot || destination.startsWith(`${repositoryRoot}/`)
    || destination === '/Applications' || destination.startsWith('/Applications/')) {
    throw new Error(`refusing unsafe Ark runtime pack output: ${destination}`)
  }
  const temporaryRoots = ['/private/tmp', resolve(tmpdir())]
  if (!temporaryRoots.some(root => destination.startsWith(`${root}/`))) {
    throw new Error(`Ark runtime pack output must stay under a temporary root: ${destination}`)
  }
  return destination
}

async function writePlanOnly(repositoryRoot, output) {
  const destination = assertSafeOutput(repositoryRoot, output)
  const plan = await createArkRuntimePlan(repositoryRoot)
  await mkdir(destination, { recursive: false })
  await writeFile(join(destination, 'closure-plan.json'), `${JSON.stringify(plan, null, 2)}\n`, { flag: 'wx' })
  return plan
}

async function pack(repositoryRoot, output) {
  const destination = assertSafeOutput(repositoryRoot, output)
  const staging = `${destination}.staging-${process.pid}-${randomBytes(6).toString('hex')}`
  await mkdir(staging, { recursive: false })
  try {
    run('npm', ['run', 'build:lib:host'], repositoryRoot)
    const repositoryManifest = JSON.parse(await readFile(join(repositoryRoot, 'package.json'), 'utf8'))
    if (typeof repositoryManifest.packageManager !== 'string'
      || !repositoryManifest.packageManager.startsWith('pnpm@')) {
      throw new Error('Ark runtime pack requires the repository pnpm packageManager pin')
    }
    const plan = await createArkRuntimePlan(repositoryRoot, { requireBuilt: true })
    const runtimeTemplate = join(staging, 'runtime-template')
    await mkdir(runtimeTemplate, { recursive: true })
    const dependencies = {}
    const packed = []
    for (const entry of plan.packages) {
      const group = tarballGroup(entry.directory)
      const tarballDirectory = join(staging, 'tarballs', group)
      await mkdir(tarballDirectory, { recursive: true })
      run('pnpm', ['--dir', entry.directory, 'pack', '--pack-destination', tarballDirectory], repositoryRoot)
      const filename = tarballName(entry)
      const path = join(tarballDirectory, filename)
      const packedManifest = JSON.parse(packedMember(path, 'package/package.json', repositoryRoot))
      for (const moduleEntry of packageJavaScriptEntries(packedManifest)) {
        assertJavaScriptModuleSyntax(
          packedMember(path, `package/${moduleEntry}`, repositoryRoot),
          `${entry.name}:${moduleEntry}`,
        )
      }
      const bytes = await readFile(path)
      const tarball = relative(runtimeTemplate, path).replaceAll('\\', '/')
      dependencies[entry.name] = `file:${tarball}`
      packed.push({
        ...entry,
        tarball,
        sha256: createHash('sha256').update(bytes).digest('hex'),
      })
    }
    const packedByName = new Map(packed.map(entry => [entry.name, entry]))
    const requiredTarball = (name) => {
      const entry = packedByName.get(name)
      if (entry === undefined) throw new Error(`Ark runtime pack lacks required tarball: ${name}`)
      return resolve(runtimeTemplate, entry.tarball)
    }
    const pluginInventoryDescriptor = packedMember(
      requiredTarball('@deepseek-ai/dsh-host-plugin-inventory'),
      'package/lib/typert.host.js',
      repositoryRoot,
    )
    if (!pluginInventoryDescriptor.includes('pluginInventory/list')) {
      throw new Error('packed Host plugin inventory lacks pluginInventory/list')
    }
    const webFetchEntry = packedMember(
      requiredTarball('@deepseek-ai/dsh-web-fetch-http'),
      'package/lib/index.js',
      repositoryRoot,
    )
    if (!webFetchEntry.includes('resolvePublicAddresses')
      || !webFetchEntry.includes('createPinnedLookup')
      || !webFetchEntry.includes('WEB_BLOCKED_URL')) {
      throw new Error('packed WebFetch lacks public-address validation and pinned transport')
    }
    const nativeRunnerEntry = packedMember(
      requiredTarball('@deepseek-ai/dsh-native-api-runner'),
      'package/lib/bin.js',
      repositoryRoot,
    )
    if (!nativeRunnerEntry.includes('runNativeApi')) {
      throw new Error('packed dedicated Native runner lacks runNativeApi')
    }
    const nativeRunnerImports = [...nativeRunnerEntry.matchAll(/from\s+["']\.\/([^"']+\.js)["']/gu)]
      .map(match => match[1])
    if (nativeRunnerImports.length === 0) {
      throw new Error('packed dedicated Native runner has no relative implementation import')
    }
    for (const imported of nativeRunnerImports) {
      packedMember(
        requiredTarball('@deepseek-ai/dsh-native-api-runner'),
        `package/lib/${imported}`,
        repositoryRoot,
      )
    }
    const packedAssertions = {
      pluginInventoryListDescriptorSha256: createHash('sha256').update(pluginInventoryDescriptor).digest('hex'),
      webFetchEntrySha256: createHash('sha256').update(webFetchEntry).digest('hex'),
      nativeRunnerEntrySha256: createHash('sha256').update(nativeRunnerEntry).digest('hex'),
    }
    await writeFile(join(runtimeTemplate, 'package.json'), `${JSON.stringify({
      name: 'ark-native-runtime-current',
      version: '0.0.0',
      private: true,
      type: 'module',
      packageManager: repositoryManifest.packageManager,
      dependencies,
    }, null, 2)}\n`)
    // Packed workspace manifests carry released semver ranges. pnpm v11 owns
    // overrides in pnpm-workspace.yaml, so force every workspace edge back to
    // the exact hashed tarball selected above instead of allowing an
    // unpublished current package to fall through to the registry.
    const workspaceTemplateSource = await readFile(
      join(repositoryRoot, 'integrations/jiuzhang/profile/pnpm-workspace.yaml'),
      'utf8',
    )
    const subprocessLocalSpecifier = dependencies['@deepseek-ai/dsh-subprocess-local']
    if (typeof subprocessLocalSpecifier !== 'string') {
      throw new Error('Ark runtime pack lacks the subprocess-local tarball build policy input')
    }
    const buildPolicyPlaceholder = '__ARK_SUBPROCESS_LOCAL_SPEC__'
    if (!workspaceTemplateSource.includes(buildPolicyPlaceholder)) {
      throw new Error('Ark runtime workspace template lacks its subprocess-local build policy placeholder')
    }
    const workspaceTemplate = workspaceTemplateSource.replaceAll(
      buildPolicyPlaceholder,
      subprocessLocalSpecifier,
    )
    const overrides = Object.entries(dependencies)
      .sort(([left], [right]) => left.localeCompare(right))
      .map(([name, specifier]) => `  ${JSON.stringify(name)}: ${JSON.stringify(specifier)}`)
      .join('\n')
    await writeFile(
      join(runtimeTemplate, 'pnpm-workspace.yaml'),
      `${workspaceTemplate.trimEnd()}\n\noverrides:\n${overrides}\n`,
    )
    for (const asset of plan.requiredFiles) {
      const destinationPath = join(runtimeTemplate, asset.path)
      await mkdir(resolve(destinationPath, '..'), { recursive: true })
      await copyFile(runtimeAssetSource(repositoryRoot, asset.path), destinationPath)
    }
    await writeFile(join(staging, 'closure-plan.json'), `${JSON.stringify(plan, null, 2)}\n`)
    await writeFile(join(staging, 'package-index.json'), `${JSON.stringify(packed, null, 2)}\n`)
    await writeFile(join(staging, 'pack-receipt.json'), `${JSON.stringify({
      version: 1,
      sourceDigest: plan.sourceDigest,
      target: plan.target,
      deferredPlatforms: plan.deferredPlatforms,
      workspacePackageCount: plan.workspacePackageCount,
      packedPackageCount: packed.length,
      packedAssertions,
    }, null, 2)}\n`)
    await rename(staging, destination)
    return plan
  } catch (error) {
    await rm(staging, { recursive: true, force: true })
    throw error
  }
}

const repositoryRoot = resolve(fileURLToPath(new URL('../../..', import.meta.url)))
const { values } = parseArgs({
  args: process.argv.slice(2),
  options: {
    out: { type: 'string' },
    'plan-only': { type: 'boolean', default: false },
  },
})
if (values.out === undefined) throw new Error('usage: pack-runtime.mjs --out /absolute/output [--plan-only]')
const plan = values['plan-only']
  ? await writePlanOnly(repositoryRoot, values.out)
  : await pack(repositoryRoot, values.out)
console.log(
  `Ark current runtime ${values['plan-only'] ? 'plan' : 'pack'}: ${String(plan.workspacePackageCount)} workspace packages, source ${plan.sourceDigest}`,
)
