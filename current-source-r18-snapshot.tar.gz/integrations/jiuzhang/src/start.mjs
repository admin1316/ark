#!/usr/bin/env node

import { spawn } from 'node:child_process'
import {
  assertStandaloneRuntimeClosure,
  createLaunchEnvironment,
  defaultJiuzhangHome,
  installRuntimeConfiguration,
  ensureProfileModuleFallback,
  purgeReservedJiuzhangPreset,
  legacyJiuzhangHome,
  migrateLegacyProductData,
  readSettingsImportRecord,
  resolveBuiltArkNativeRunner,
  resolveSessionWorkingDirectory,
  seedLocalModelProvider,
} from './runtime.mjs'

const home = process.env.JIUZHANG_DSH_HOME || defaultJiuzhangHome()
await assertStandaloneRuntimeClosure()
if (!process.env.JIUZHANG_DSH_HOME) {
  try {
    await migrateLegacyProductData(legacyJiuzhangHome(), home)
  } catch (error) {
    console.error(`Ark 数据迁移失败：${error?.message ?? error}`)
    process.exit(1)
  }
  const imported = await readSettingsImportRecord(home)
  if (imported !== undefined) {
    console.warn(
      'Ark 已从旧版本导入设置：默认 Agent = '
      + `${imported.agentPresetDefault ?? '未设置'}，权限 = ${imported.permissionPresetDefault ?? '未设置'}。`
      + '旧值已保留（见 .ark-settings-import.json）；可在设置中改回 Ark 安全默认（Ark 预设 + 只读）。',
    )
  }
}
await installRuntimeConfiguration(home)
// 保留 ID 清理：preset service 暴露前删除历史 jiuzhang 目录（幂等）。
await purgeReservedJiuzhangPreset(home)
await ensureProfileModuleFallback(home)
// Opt-in: set ARK_SEED_OLLAMA=1 to seed the ready-to-use local provider.
if (process.env.ARK_SEED_OLLAMA === '1') {
  await seedLocalModelProvider(home)
}

// launcher 自有参数：--parent-pid 只用于父进程死亡感知，绝不透传 backend。
const forwardedArgs = []
let parentPid = null
for (let index = 2; index < process.argv.length; index += 1) {
  const arg = process.argv[index]
  if (arg === '--parent-pid') {
    const value = process.argv[index + 1]
    if (value === undefined || !/^\d+$/.test(value) || Number(value) <= 1) {
      throw new Error('Invalid --parent-pid')
    }
    parentPid = Number(value)
    index += 1
    continue
  }
  forwardedArgs.push(arg)
}

// 测试钩子：JIUZHANG_LAUNCHER_CHILD 以 dummy child 替换 built CLI（生产不设置）。
const testChild = process.env.JIUZHANG_LAUNCHER_CHILD
const childArgs = testChild === undefined
  ? [
      await resolveBuiltArkNativeRunner(),
      ...forwardedArgs,
    ]
  : [
      testChild,
      ...forwardedArgs,
    ]
const child = spawn(process.execPath, childArgs, {
  cwd: await resolveSessionWorkingDirectory(),
  env: createLaunchEnvironment(home),
  stdio: 'inherit',
})

let shuttingDown = false
let parentWatch = null

// parent 死亡与 launcher 信号统一汇聚到 shutdownOnce，只执行一次，
// 且只 TERM 自己创建并持有句柄的 child（先 TERM，超时才 KILL）；
// child 自行退出时 exit handler 清理 watcher 后 launcher 自然退出。
const shutdownOnce = signal => {
  if (shuttingDown) return
  shuttingDown = true
  if (parentWatch !== null) {
    clearInterval(parentWatch)
    parentWatch = null
  }
  if (child.exitCode === null && child.signalCode === null) {
    child.kill(signal ?? 'SIGTERM')
    const deadline = setTimeout(() => {
      if (child.exitCode === null && child.signalCode === null) {
        child.kill('SIGKILL')
      }
    }, 4_000)
    deadline.unref()
  }
}

for (const signal of ['SIGINT', 'SIGTERM']) {
  process.on(signal, () => shutdownOnce(signal))
}

// 父进程死亡感知：UI crash 后 launcher 被 launchd 收养（ppid 变 1），
// 或 --parent-pid 对应进程不再存活时按统一路径收口，不留下 orphan backend。
if (parentPid !== null) {
  parentWatch = setInterval(() => {
    let alive = true
    try {
      process.kill(parentPid, 0)
    } catch (error) {
      if (error?.code === 'ESRCH') alive = false
    }
    if (process.ppid !== parentPid || !alive) shutdownOnce()
  }, 2_000)
  parentWatch.unref()
}

child.once('error', error => {
  console.error(`九章天幕启动失败：${error.message}`)
  process.exitCode = 1
})

child.once('exit', (code, signal) => {
  if (parentWatch !== null) {
    clearInterval(parentWatch)
    parentWatch = null
  }
  process.exitCode = signal === null ? (code ?? 1) : 1
})
