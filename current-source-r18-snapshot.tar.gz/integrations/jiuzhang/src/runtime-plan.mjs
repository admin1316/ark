import { createHash } from 'node:crypto'
import { lstat, readFile, readdir } from 'node:fs/promises'
import { isAbsolute, join, relative, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

export const ARK_RUNTIME_ROOT_PACKAGES = ['@deepseek-ai/dsh-native-api-runner']
const ARK_RUNTIME_TARGET = Object.freeze({ id: 'macos-arm64', os: 'darwin', cpu: 'arm64' })
const ARK_RUNTIME_PROFILE_FILES = new Set([
  'jiuzhang/profile/package.json',
  'jiuzhang/profile/cordis.patch.yml',
  'jiuzhang/profile/pnpm-workspace.yaml',
  'jiuzhang/profile/forbidden-runtime-packages.json',
])

async function optionalLstat(path) {
  try {
    return await lstat(path)
  } catch (error) {
    if (error?.code === 'ENOENT') return undefined
    throw error
  }
}

async function childDirectories(root) {
  if (await optionalLstat(root) === undefined) return []
  return (await readdir(root, { withFileTypes: true }))
    .filter(entry => entry.isDirectory() && !entry.isSymbolicLink())
    .map(entry => join(root, entry.name))
    .sort()
}

async function workspaceManifestPaths(repositoryRoot) {
  const paths = []
  for (const group of await childDirectories(join(repositoryRoot, 'packages'))) {
    for (const packageRoot of await childDirectories(group)) paths.push(join(packageRoot, 'package.json'))
  }
  for (const packageRoot of await childDirectories(join(repositoryRoot, 'vendor'))) {
    paths.push(join(packageRoot, 'package.json'))
  }
  for (const packageRoot of await childDirectories(join(repositoryRoot, 'apps'))) {
    paths.push(join(packageRoot, 'package.json'))
  }
  paths.push(join(repositoryRoot, 'native/landlock-run/package.json'))
  for (const packageRoot of await childDirectories(join(repositoryRoot, 'native/landlock-run/packages'))) {
    paths.push(join(packageRoot, 'package.json'))
  }
  return paths.filter(path => isAbsolute(path) && path.startsWith(`${repositoryRoot}/`))
}

async function sourceInputFiles(packageRoot) {
  const files = []
  const addTree = async (root) => {
    if (await optionalLstat(root) === undefined) return
    for (const entry of await readdir(root, { withFileTypes: true })) {
      const path = join(root, entry.name)
      if (entry.isDirectory() && !entry.isSymbolicLink()) await addTree(path)
      else if (entry.isFile()) files.push(path)
    }
  }
  for (const direct of ['package.json', 'tsconfig.json', 'cordis.patch.yml']) {
    const path = join(packageRoot, direct)
    if ((await optionalLstat(path))?.isFile() === true) files.push(path)
  }
  await addTree(join(packageRoot, 'src'))
  await addTree(join(packageRoot, 'config'))
  return files.sort()
}

async function sourceInputDigest(packageRoot) {
  const digest = createHash('sha256')
  for (const path of await sourceInputFiles(packageRoot)) {
    digest.update(`${relative(packageRoot, path).replaceAll('\\', '/')}\u0000`)
    digest.update(await readFile(path))
    digest.update('\n')
  }
  return digest.digest('hex')
}

async function loadWorkspace(repositoryRoot) {
  const workspace = new Map()
  for (const path of await workspaceManifestPaths(repositoryRoot)) {
    if (await optionalLstat(path) === undefined) continue
    const raw = await readFile(path)
    const manifest = JSON.parse(raw.toString('utf8'))
    if (typeof manifest.name !== 'string' || typeof manifest.version !== 'string') {
      throw new Error(`Ark runtime workspace manifest lacks name/version: ${path}`)
    }
    if (workspace.has(manifest.name)) throw new Error(`Ark runtime workspace package is duplicated: ${manifest.name}`)
    const packageRoot = resolve(path, '..')
    workspace.set(manifest.name, {
      directory: relative(repositoryRoot, packageRoot).replaceAll('\\', '/'),
      manifest,
      manifestSha256: createHash('sha256').update(raw).digest('hex'),
      sourceSha256: await sourceInputDigest(packageRoot),
    })
  }
  return workspace
}

/** npm-compatible positive/negative platform selector for one manifest axis. */
function platformAxisAllows(values, actual) {
  if (!Array.isArray(values) || !values.every(value => typeof value === 'string')) return true
  if (values.includes(`!${actual}`)) return false
  const positive = values.filter(value => !value.startsWith('!'))
  return positive.length === 0 || positive.includes(actual)
}

/** Whether one workspace package can be installed for Ark.app's exact target. */
function supportsArkRuntimeTarget(manifest) {
  return platformAxisAllows(manifest.os, ARK_RUNTIME_TARGET.os)
    && platformAxisAllows(manifest.cpu, ARK_RUNTIME_TARGET.cpu)
}

/** Resolve one runtime-template asset back to its current repository source. */
export function runtimeAssetSource(repositoryRoot, relativePath) {
  if (ARK_RUNTIME_PROFILE_FILES.has(relativePath)) {
    return join(repositoryRoot, 'integrations/jiuzhang/profile', relativePath.slice('jiuzhang/profile/'.length))
  }
  if (['start.mjs', 'runtime.mjs', 'runtime-closure.mjs'].includes(relativePath)) {
    return join(repositoryRoot, 'integrations/jiuzhang/src', relativePath)
  }
  throw new Error(`Ark runtime policy names an unsupported source asset: ${relativePath}`)
}

/**
 * Build the exact current-source workspace closure rooted at Ark's dedicated runner.
 * @param {string} root - absolute DeepSeek Harness repository root.
 * @param {{requireBuilt?: boolean, allowForbiddenAnalysis?: boolean}} options - built-entry and diagnostic controls.
 * @returns {Promise<object>} deterministic closure plan for pack and receipt generation.
 */
export async function createArkRuntimePlan(root, options = {}) {
  if (!isAbsolute(root)) throw new Error('Ark runtime plan root must be absolute')
  const repositoryRoot = resolve(root)
  const policyPath = join(repositoryRoot, 'integrations/jiuzhang/profile/forbidden-runtime-packages.json')
  const policyRaw = await readFile(policyPath)
  const policy = JSON.parse(policyRaw.toString('utf8'))
  if (!Array.isArray(policy.required) || !policy.required.every(name => typeof name === 'string')
    || !Array.isArray(policy.requiredFiles) || !policy.requiredFiles.every(path => typeof path === 'string')
    || !Array.isArray(policy.exact) || !Array.isArray(policy.prefixes)) {
    throw new Error(`Ark runtime policy is invalid: ${policyPath}`)
  }

  const workspace = await loadWorkspace(repositoryRoot)
  const reached = new Map()
  const queue = [...ARK_RUNTIME_ROOT_PACKAGES]
  const parents = new Map(ARK_RUNTIME_ROOT_PACKAGES.map(name => [name, undefined]))
  const external = new Map()
  const missingWorkspace = new Set()
  for (let index = 0; index < queue.length; index++) {
    const name = queue[index]
    if (reached.has(name)) continue
    const record = workspace.get(name)
    if (record === undefined) {
      missingWorkspace.add(name)
      continue
    }
    reached.set(name, record)
    const peerMeta = record.manifest.peerDependenciesMeta ?? {}
    for (const section of ['dependencies', 'optionalDependencies', 'peerDependencies']) {
      const dependencies = record.manifest[section]
      if (dependencies === undefined || dependencies === null || typeof dependencies !== 'object'
        || Array.isArray(dependencies)) continue
      for (const dependency of Object.keys(dependencies).sort()) {
        const range = dependencies[dependency]
        if (section === 'peerDependencies' && peerMeta[dependency]?.optional === true) continue
        if (workspace.has(dependency)) {
          const dependencyRecord = workspace.get(dependency)
          if (section === 'optionalDependencies' && !supportsArkRuntimeTarget(dependencyRecord.manifest)) {
            continue
          }
          if (!parents.has(dependency)) parents.set(dependency, name)
          queue.push(dependency)
        } else if (typeof range === 'string' && range.startsWith('workspace:')) {
          missingWorkspace.add(`${name} -> ${dependency}`)
        } else {
          external.set(`${dependency}\u0000${String(range)}`, { name: dependency, range: String(range) })
        }
      }
    }
  }
  if (missingWorkspace.size > 0) {
    throw new Error(`Ark runtime plan has unresolved workspace packages: ${[...missingWorkspace].sort().join(', ')}`)
  }

  const reachedNames = new Set(reached.keys())
  const missingRequired = policy.required.filter(name => !reachedNames.has(name)).sort()
  if (missingRequired.length > 0) {
    throw new Error(`Ark runtime plan lacks required package identities: ${missingRequired.join(', ')}`)
  }
  const forbidden = [...reachedNames]
    .filter(name => policy.exact.includes(name) || policy.prefixes.some(prefix => name.startsWith(prefix)))
    .sort()
  const forbiddenChains = forbidden.map((name) => {
    const chain = [name]
    let parent = parents.get(name)
    while (parent !== undefined) {
      chain.unshift(parent)
      parent = parents.get(parent)
    }
    return chain.join(' -> ')
  })
  if (forbidden.length > 0 && options.allowForbiddenAnalysis !== true) {
    throw new Error(`Ark runtime plan reaches forbidden packages: ${forbiddenChains.join('; ')}`)
  }

  const assetDigests = []
  for (const relativePath of policy.requiredFiles) {
    const source = runtimeAssetSource(repositoryRoot, relativePath)
    const stat = await optionalLstat(source)
    if (stat === undefined || !stat.isFile() || stat.isSymbolicLink()) {
      throw new Error(`Ark runtime plan lacks required current-source asset: ${source}`)
    }
    const bytes = await readFile(source)
    assetDigests.push({
      path: relativePath,
      sha256: createHash('sha256').update(bytes).digest('hex'),
    })
  }

  const packages = [...reached.entries()]
    .map(([name, record]) => ({
      name,
      version: record.manifest.version,
      directory: record.directory,
      manifestSha256: record.manifestSha256,
      sourceSha256: record.sourceSha256,
    }))
    .sort((left, right) => left.name.localeCompare(right.name))
  if (options.requireBuilt === true) {
    const staleBuilds = []
    for (const entry of packages) {
      const main = workspace.get(entry.name)?.manifest.main
      if (typeof main !== 'string') continue
      const built = join(repositoryRoot, entry.directory, main)
      const stat = await optionalLstat(built)
      if (stat === undefined || !stat.isFile()) staleBuilds.push(`${entry.name}: ${relative(repositoryRoot, built)}`)
    }
    if (staleBuilds.length > 0) {
      throw new Error(`Ark runtime plan requires fresh built package entries: ${staleBuilds.join(', ')}`)
    }
  }

  const digest = createHash('sha256')
  for (const entry of packages) {
    digest.update(`${entry.name}\u0000${entry.version}\u0000${entry.manifestSha256}\u0000${entry.sourceSha256}\n`)
  }
  for (const asset of assetDigests) digest.update(`${asset.path}\u0000${asset.sha256}\n`)
  return {
    version: 1,
    target: ARK_RUNTIME_TARGET.id,
    deferredPlatforms: ['win-x64'],
    roots: [...ARK_RUNTIME_ROOT_PACKAGES],
    requiredPackages: [...policy.required].sort(),
    requiredFiles: assetDigests,
    forbiddenPackages: forbidden,
    forbiddenChains,
    workspacePackageCount: packages.length,
    packages,
    externalDependencies: [...external.values()].sort((left, right) => (
      left.name.localeCompare(right.name) || left.range.localeCompare(right.range)
    )),
    sourceDigest: digest.digest('hex'),
  }
}

if (process.argv[1] !== undefined && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url))) {
  const plan = await createArkRuntimePlan(resolve(process.argv[2] ?? '.'))
  process.stdout.write(`${JSON.stringify(plan, null, 2)}\n`)
}
