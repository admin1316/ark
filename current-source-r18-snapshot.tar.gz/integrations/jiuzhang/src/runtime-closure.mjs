import { lstat, readFile, readdir } from 'node:fs/promises'
import { spawnSync } from 'node:child_process'
import { isAbsolute, join, parse, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'

async function optionalLstat(path) {
  try {
    return await lstat(path)
  } catch (error) {
    if (error?.code === 'ENOENT') return undefined
    throw error
  }
}

async function packageRecordsAt(modulesRoot) {
  const names = new Set()
  const manifests = []
  const rootStat = await optionalLstat(modulesRoot)
  if (rootStat === undefined) return { names, manifests }
  if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) {
    throw new Error(`Ark runtime package root is not an ordinary directory: ${modulesRoot}`)
  }
  for (const entry of await readdir(modulesRoot, { withFileTypes: true })) {
    if (entry.name.startsWith('.')) continue
    if (entry.name.startsWith('@')) {
      if (!entry.isDirectory() || entry.isSymbolicLink()) {
        throw new Error(`Ark runtime package scope is not an ordinary directory: ${join(modulesRoot, entry.name)}`)
      }
      const scope = join(modulesRoot, entry.name)
      for (const child of await readdir(scope, { withFileTypes: true })) {
        if (!child.isDirectory() && !child.isSymbolicLink()) continue
        await addPackageRecord(names, manifests, join(scope, child.name))
      }
    } else if (entry.isDirectory() || entry.isSymbolicLink()) {
      await addPackageRecord(names, manifests, join(modulesRoot, entry.name))
    }
  }
  return { names, manifests }
}

async function addPackageRecord(names, manifests, packageRoot) {
  try {
    const manifest = JSON.parse(await readFile(join(packageRoot, 'package.json'), 'utf8'))
    if (typeof manifest?.name === 'string') {
      names.add(manifest.name)
      manifests.push({ name: manifest.name, manifest, packageRoot })
    }
  } catch (error) {
    if (error?.code !== 'ENOENT') throw error
  }
}

/** Return concrete JavaScript entry files whose syntax must be valid in plain Node. */
export function packageJavaScriptEntries(manifest) {
  const entries = new Set()
  const add = (value) => {
    if (typeof value !== 'string' || value.includes('*')) return
    const normalized = value.startsWith('./') ? value.slice(2) : value
    if (normalized.startsWith('/') || normalized.includes('\\') || normalized.split('/').includes('..')) {
      throw new Error(`Ark runtime manifest has an unsafe JavaScript entry: ${value}`)
    }
    if (/\.[cm]?js$/u.test(normalized)) entries.add(normalized)
  }
  const visit = (value) => {
    if (typeof value === 'string') return add(value)
    if (Array.isArray(value)) {
      for (const child of value) visit(child)
    } else if (value !== null && typeof value === 'object') {
      for (const child of Object.values(value)) visit(child)
    }
  }
  add(manifest?.main)
  if (typeof manifest?.bin === 'string') add(manifest.bin)
  else if (manifest?.bin !== null && typeof manifest?.bin === 'object' && !Array.isArray(manifest.bin)) {
    for (const value of Object.values(manifest.bin)) add(value)
  }
  visit(manifest?.exports)
  return [...entries].sort()
}

/** Reject one packed or installed module entry that plain Node cannot parse. */
export function assertJavaScriptModuleSyntax(source, label) {
  const inputType = label.endsWith('.cjs') ? 'commonjs' : 'module'
  const result = spawnSync(
    process.execPath,
    ['--check', `--input-type=${inputType}`, '-'],
    { input: source, encoding: 'utf8', stdio: ['pipe', 'pipe', 'pipe'] },
  )
  if (result.error !== undefined) {
    throw new Error(`Ark runtime could not syntax-check ${label}: ${result.error.message}`)
  }
  if (result.status !== 0) {
    const detail = [result.stdout, result.stderr].filter(Boolean).join('\n').trim()
    const outcome = result.signal === null ? `exit ${String(result.status)}` : `signal ${result.signal}`
    throw new Error(`Ark runtime has an unparseable JavaScript entry ${label} (${outcome})${detail === '' ? '' : `\n${detail}`}`)
  }
}

async function assertInstalledEntrypointSyntax(records) {
  for (const { name, manifest, packageRoot } of records) {
    for (const entry of packageJavaScriptEntries(manifest)) {
      const path = resolve(packageRoot, entry)
      if (path === packageRoot || !path.startsWith(`${packageRoot}/`)) {
        throw new Error(`Ark runtime package ${name} has an escaping JavaScript entry: ${entry}`)
      }
      const stat = await optionalLstat(path)
      if (stat === undefined || !stat.isFile()) {
        throw new Error(`Ark runtime package ${name} lacks its JavaScript entry: ${entry}`)
      }
      assertJavaScriptModuleSyntax(await readFile(path, 'utf8'), `${name}:${entry}`)
    }
  }
}

async function installedPackageRecords(runtimeRoot) {
  const modules = join(runtimeRoot, 'node_modules')
  const direct = await packageRecordsAt(modules)
  const names = direct.names
  const manifests = direct.manifests
  const store = join(modules, '.pnpm')
  if (await optionalLstat(store) === undefined) return { names, manifests }
  for (const locator of await readdir(store, { withFileTypes: true })) {
    if (!locator.isDirectory()) continue
    const records = await packageRecordsAt(join(store, locator.name, 'node_modules'))
    for (const name of records.names) names.add(name)
    manifests.push(...records.manifests)
  }
  return { names, manifests }
}

/**
 * Assert that a standalone Ark runtime contains its dedicated entry and no
 * forbidden Web/headless package under either direct links or the pnpm store.
 * Direct `node_modules.*` siblings are rejected because bundle copying would
 * otherwise retain a second unchecked package tree.
 * @param {string} runtimePath - Absolute standalone runtime root.
 * @param {string} policyPath - Absolute JSON policy path.
 * @returns {Promise<{packageCount: number}>} Count of unique package identities inspected.
 */
export async function assertArkRuntimeClosure(runtimePath, policyPath) {
  if (!isAbsolute(runtimePath) || !isAbsolute(policyPath)) {
    throw new Error('Ark runtime closure paths must be absolute')
  }
  const runtimeRoot = resolve(runtimePath)
  if (runtimeRoot === parse(runtimeRoot).root) throw new Error('Ark runtime root cannot be a filesystem root')
  const bypasses = (await readdir(runtimeRoot, { withFileTypes: true }))
    .filter(entry => entry.name.startsWith('node_modules.'))
    .map(entry => entry.name)
    .sort()
  if (bypasses.length > 0) {
    throw new Error(`Ark runtime contains unchecked package-tree siblings: ${bypasses.join(', ')}`)
  }
  const entry = join(
    runtimeRoot,
    'node_modules',
    '@deepseek-ai',
    'dsh-native-api-runner',
    'lib',
    'bin.js',
  )
  const entryStat = await optionalLstat(entry)
  if (entryStat === undefined || !entryStat.isFile()) {
    throw new Error(`Ark runtime lacks the dedicated native API entry: ${entry}`)
  }
  const policy = JSON.parse(await readFile(policyPath, 'utf8'))
  if (!Array.isArray(policy?.required) || !policy.required.every(value => typeof value === 'string')
    || !Array.isArray(policy?.requiredFiles) || !policy.requiredFiles.every(value => typeof value === 'string')
    || !Array.isArray(policy?.exact) || !policy.exact.every(value => typeof value === 'string')
    || !Array.isArray(policy?.prefixes) || !policy.prefixes.every(value => typeof value === 'string')) {
    throw new Error(`Ark runtime package policy is invalid: ${policyPath}`)
  }
  for (const relative of policy.requiredFiles) {
    if (isAbsolute(relative) || resolve(runtimeRoot, relative) === runtimeRoot
      || !resolve(runtimeRoot, relative).startsWith(`${runtimeRoot}/`)) {
      throw new Error(`Ark runtime package policy has an invalid required file: ${relative}`)
    }
    const requiredFile = join(runtimeRoot, relative)
    const requiredStat = await optionalLstat(requiredFile)
    if (requiredStat === undefined || !requiredStat.isFile() || requiredStat.isSymbolicLink()) {
      throw new Error(`Ark runtime lacks required current-source asset: ${requiredFile}`)
    }
  }
  const records = await installedPackageRecords(runtimeRoot)
  const names = records.names
  const missing = policy.required.filter(name => !names.has(name)).sort()
  if (missing.length > 0) {
    throw new Error(`Ark runtime lacks required package identities: ${missing.join(', ')}`)
  }
  const exact = new Set(policy.exact)
  const forbidden = [...names]
    .filter(name => exact.has(name) || policy.prefixes.some(prefix => name.startsWith(prefix)))
    .sort()
  if (forbidden.length > 0) {
    throw new Error(`Ark runtime contains forbidden package identities: ${forbidden.join(', ')}`)
  }
  const forbiddenEdges = new Set()
  for (const { name, manifest } of records.manifests) {
    for (const key of ['dependencies', 'optionalDependencies', 'peerDependencies']) {
      const table = manifest[key]
      if (table === undefined || table === null || typeof table !== 'object' || Array.isArray(table)) continue
      for (const dependency of Object.keys(table)) {
        if (exact.has(dependency) || policy.prefixes.some(prefix => dependency.startsWith(prefix))) {
          forbiddenEdges.add(`${name} -> ${dependency}`)
        }
      }
    }
  }
  if (forbiddenEdges.size > 0) {
    throw new Error(`Ark runtime contains forbidden package manifest edges: ${[...forbiddenEdges].sort().join(', ')}`)
  }
  await assertInstalledEntrypointSyntax(records.manifests)
  return { packageCount: names.size }
}

if (process.argv[1] !== undefined && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url))) {
  const [runtimePath, policyPath] = process.argv.slice(2)
  try {
    const result = await assertArkRuntimeClosure(runtimePath ?? '', policyPath ?? '')
    console.log(`Ark runtime closure verified: ${String(result.packageCount)} package identities`)
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error))
    process.exitCode = 2
  }
}
