import assert from 'node:assert/strict'
import { spawn } from 'node:child_process'
import { EventEmitter } from 'node:events'
import { readFileSync } from 'node:fs'
import { mkdtemp, readFile, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import test from 'node:test'
import { setTimeout as sleep } from 'node:timers/promises'
import { fileURLToPath } from 'node:url'
import {
  CleanupTimeoutError,
  processIsAlive as isAlive,
  runCleanupSteps,
  signalOwnedProcess,
  withCleanupDeadline,
} from './helpers/process-liveness.mjs'
import {
  createInstallProcessOwnership,
  retainedBackendIsAlive,
} from './helpers/install-process-ownership.mjs'

const root = resolve(fileURLToPath(new URL('../../..', import.meta.url)))
const startMjs = join(root, 'integrations/jiuzhang/src/start.mjs')
const backendProcessSwift = join(
  root,
  'integrations/jiuzhang/native/Sources/JiuzhangShellCore/BackendProcess.swift',
)

const isOwnedTestPid = pid => Number.isSafeInteger(pid) && pid > 1

/** A dummy child that records its pid and exits cleanly on TERM.
 * 配置走 argv（launcher 会透传非自有参数），因为 backend 的 launch env
 * 是白名单式构造，测试私有 env 变量到不了 child。 */
const longLivedChild = `
import { appendFileSync, writeFileSync } from 'node:fs'
const valueOf = prefix => {
  const arg = process.argv.find(entry => entry.startsWith(prefix))
  return arg === undefined ? undefined : arg.slice(prefix.length)
}
writeFileSync(valueOf('--child-pid-file='), String(process.pid))
process.on('SIGTERM', () => {
  const termLog = valueOf('--term-log=')
  if (termLog) appendFileSync(termLog, 'term\\n')
  process.exit(0)
})
setInterval(() => {}, 1000)
`

/** A backend that records ownership but deliberately ignores TERM, exercising
 * the launcher's bounded KILL path rather than the test cleanup fallback. */
const stubbornChild = `
import { writeFileSync } from 'node:fs'
const pidFile = process.argv.find(entry => entry.startsWith('--child-pid-file='))?.split('=')[1]
writeFileSync(pidFile, String(process.pid))
process.on('SIGTERM', () => {})
setInterval(() => {}, 1000)
`

/** A dummy parent that spawns the launcher with its own pid, records the
 * launcher pid, and sleeps until killed. */
const dummyParent = `
import { spawn } from 'node:child_process'
import { writeFileSync } from 'node:fs'
const argv = JSON.parse(process.env.LAUNCH_ARGV)
const launcher = spawn(process.execPath, [...argv, '--parent-pid', String(process.pid)], {
  stdio: 'ignore',
  env: process.env,
})
writeFileSync(process.env.LAUNCHER_PID_FILE, String(launcher.pid))
setInterval(() => {}, 1000)
`

const launch = (
  home,
  { parentPid, childScript, extraEnv = {}, childArgs = [] } = {},
) => {
  const argv = [startMjs, '--port', '0']
  if (parentPid !== undefined) {
    argv.push('--parent-pid', String(parentPid))
  }
  argv.push(...childArgs)

  return spawn(process.execPath, argv, {
    env: {
      ...process.env,
      JIUZHANG_DSH_HOME: home,
      JIUZHANG_LAUNCHER_CHILD: childScript,
      ...extraEnv,
    },
    stdio: ['ignore', 'pipe', 'pipe'],
  })
}

const spawnDummyParent = (
  home,
  { childScript, launcherPidFile, extraEnv = {}, childArgs = [] },
) => {
  const parentPath = join(home, 'parent.mjs')

  return spawn(process.execPath, [parentPath], {
    env: {
      ...process.env,
      JIUZHANG_DSH_HOME: home,
      JIUZHANG_LAUNCHER_CHILD: childScript,
      LAUNCHER_PID_FILE: launcherPidFile,
      LAUNCH_ARGV: JSON.stringify([
        startMjs,
        '--port', '0',
        ...childArgs,
      ]),
      ...extraEnv,
    },
    stdio: 'ignore',
  })
}

const waitExit = async (proc, timeoutMs) => {
  const deadline = Date.now() + timeoutMs
  while (proc.exitCode === null && proc.signalCode === null) {
    if (Date.now() > deadline) return false
    await sleep(100)
  }
  return true
}

const waitPidDead = async (pid, timeoutMs) => {
  const deadline = Date.now() + timeoutMs
  while (isAlive(pid)) {
    if (Date.now() > deadline) return false
    await sleep(100)
  }
  return true
}

const waitFile = async (path, timeoutMs) => {
  const deadline = Date.now() + timeoutMs
  while (true) {
    try {
      return await readFile(path, 'utf8')
    } catch {
      if (Date.now() > deadline) return null
      await sleep(100)
    }
  }
}

const readOptionalPidFile = async path => {
  try {
    return await readFile(path, 'utf8')
  } catch (error) {
    if (error?.code === 'ENOENT') return null
    throw error
  }
}

const runCleanups = async (label, cleanups) => {
  await runCleanupSteps(label, [], cleanups.map((run, index) => ({
    label: `${label} step ${String(index + 1)}`,
    timeoutMs: 8_000,
    run,
  })))
}

/** 只清理本测试刚刚创建并记录的 PID：先 TERM，短等后 KILL；ESRCH 容忍。 */
const terminateTestPid = async pid => {
  if (pid === null || pid === undefined) return
  if (!isOwnedTestPid(pid)) throw new Error(`cleanup received unsafe test pid: ${String(pid)}`)
  if (!isAlive(pid)) return
  try {
    process.kill(pid, 'SIGTERM')
  } catch (error) {
    if (error?.code !== 'ESRCH') throw error
  }
  if (await waitPidDead(pid, 2_000)) return
  try {
    process.kill(pid, 'SIGKILL')
  } catch (error) {
    if (error?.code !== 'ESRCH') throw error
  }
  if (!await waitPidDead(pid, 2_000)) throw new Error(`test pid ${String(pid)} survived SIGKILL cleanup`)
}

const writeScript = async (home, name, body) => {
  const path = join(home, name)
  await writeFile(path, body)
  return path
}

test('lifecycle: PID helpers reject sentinels and distinguish ESRCH from EPERM without OS signals', () => {
  const calls = []
  const alive = (pid, signal) => {
    calls.push([pid, signal])
    return true
  }
  for (const invalid of [undefined, null, 0, 1, -1, Number.NaN, Number.POSITIVE_INFINITY, 2.5]) {
    assert.equal(isAlive(invalid, alive), false)
  }
  assert.deepEqual(calls, [], 'invalid PID values never reach the signal boundary')

  const esrch = Object.assign(new Error('gone'), { code: 'ESRCH' })
  assert.equal(isAlive(42, (pid, signal) => {
    calls.push([pid, signal])
    throw esrch
  }), false)

  const eperm = Object.assign(new Error('denied'), { code: 'EPERM' })
  assert.throws(() => isAlive(43, (pid, signal) => {
    calls.push([pid, signal])
    throw eperm
  }), error => error === eperm)
  assert.deepEqual(calls, [[42, 0], [43, 0]])

  assert.equal(signalOwnedProcess(44, 'SIGTERM', (pid, signal) => {
    calls.push([pid, signal])
    throw esrch
  }), false)
  assert.throws(() => signalOwnedProcess(45, 'SIGKILL', (pid, signal) => {
    calls.push([pid, signal])
    throw eperm
  }), error => error === eperm)
  assert.throws(() => signalOwnedProcess(0, 'SIGKILL', alive), /unsafe test pid/)
  assert.deepEqual(calls, [[42, 0], [43, 0], [44, 'SIGTERM'], [45, 'SIGKILL']])
})

test('lifecycle: cleanup runner attempts every task and preserves failure order', async () => {
  const order = []
  const first = new Error('first cleanup failed')
  const third = new Error('third cleanup failed')
  await assert.rejects(runCleanups('contract', [
    () => { order.push('first'); throw first },
    () => { order.push('second') },
    () => { order.push('third'); throw third },
  ]), error => (
    error instanceof AggregateError
      && error.errors[0] === first
      && error.errors[1] === third
  ))
  assert.deepEqual(order, ['first', 'second', 'third'])
})

test('lifecycle: deadline cleanup preserves [primary, timeout, later failure] and continues', async () => {
  const primary = new Error('primary failed')
  const later = new Error('later cleanup failed')
  const order = []
  await assert.rejects(runCleanupSteps('deadline contract', [primary], [
    {
      label: 'never-settling first cleanup',
      timeoutMs: 20,
      run: () => new Promise(() => {}),
    },
    {
      label: 'later cleanup',
      timeoutMs: 20,
      run: () => { order.push('later'); throw later },
    },
  ]), error => (
    error instanceof AggregateError
      && error.errors[0] === primary
      && error.errors[1] instanceof CleanupTimeoutError
      && error.errors[2] === later
  ))
  assert.deepEqual(order, ['later'])
})

test('lifecycle: deadline abort detaches the losing operation listener', async () => {
  const emitter = new EventEmitter()
  let observedAbort = false
  await assert.rejects(withCleanupDeadline('listener detach', 20, signal => new Promise(resolve => {
    const onExit = () => { resolve(true) }
    const onAbort = () => {
      observedAbort = true
      emitter.off('exit', onExit)
      resolve(false)
    }
    emitter.once('exit', onExit)
    signal.addEventListener('abort', onAbort, { once: true })
  })), error => error instanceof CleanupTimeoutError)
  assert.equal(observedAbort, true)
  assert.equal(emitter.listenerCount('exit'), 0)
})

test('lifecycle: retained install ownership rejects PID reuse and makes cleanup idempotent', async () => {
  const child = { pid: 42, exitCode: null, signalCode: null }
  let rows = [
    { pid: 42, parentPid: 10, started: 'launcher-a' },
    { pid: 43, parentPid: 42, started: 'backend-a' },
  ]
  let reads = 0
  let cleanupRuns = 0
  const signals = []
  const captureGate = Promise.withResolvers()
  const ownership = createInstallProcessOwnership(async () => { reads += 1; return captureGate.promise })
  const firstCapture = ownership.capture(child)
  const secondCapture = ownership.capture(child)
  captureGate.resolve(rows)
  const [firstState, secondState] = await Promise.all([firstCapture, secondCapture])
  assert.equal(firstState, secondState, 'concurrent capture shares one retained state')
  child.exitCode = 0
  rows = [
    { pid: 42, parentPid: 999, started: 'unrelated-launcher' },
    { pid: 43, parentPid: 42, started: 'backend-a' },
  ]
  const cleanup = async state => {
    cleanupRuns += 1
    for (const backend of state.backends) {
      if (retainedBackendIsAlive(rows, state, backend)) signals.push(backend.pid)
    }
  }
  await ownership.cleanup(child, cleanup)
  await ownership.cleanup(child, cleanup)
  assert.equal(reads, 1, 'cleanup never rediscovers from the exited numeric launcher PID')
  assert.equal(cleanupRuns, 1, 'second cleanup reuses the retained cleanup promise')
  assert.deepEqual(signals, [], 'launcher PID reuse cannot redirect a backend signal')
})

test('lifecycle: install ownership retains ps failure and emits zero backend signals', async () => {
  const child = { pid: 52, exitCode: null, signalCode: null }
  const psFailure = new Error('ps failed')
  let reads = 0
  let cleanupRuns = 0
  const signals = []
  const ownership = createInstallProcessOwnership(async () => { reads += 1; throw psFailure })
  await assert.rejects(ownership.capture(child), error => error === psFailure)
  await ownership.cleanup(child, async state => {
    cleanupRuns += 1
    for (const backend of state.backends) signals.push(backend.pid)
  })
  await ownership.cleanup(child, async () => { cleanupRuns += 1 })
  assert.equal(reads, 1)
  assert.equal(cleanupRuns, 1)
  assert.deepEqual(signals, [])
})

test('lifecycle: parent alive keeps the backend running (no false kill)', { timeout: 30_000 }, async t => {
  const home = await mkdtemp(join(tmpdir(), 'ark-lifecycle-alive-'))
  const pidFile = join(home, 'child.pid')
  const childScript = await writeScript(home, 'child.mjs', longLivedChild)
  const launcher = launch(home, { parentPid: process.pid, childScript, childArgs: [`--child-pid-file=${pidFile}`] })
  let childPid = null
  const launcherPid = launcher.pid
  t.after(async () => {
    await runCleanups('parent-alive lifecycle', [
      async () => { await terminateTestPid(launcherPid) },
      async () => {
        if (childPid === null) {
          const text = await readOptionalPidFile(pidFile)
          if (text) childPid = Number(text.trim())
        }
        await terminateTestPid(childPid)
      },
      async () => { await rm(home, { recursive: true, force: true }) },
    ])
  })

  const childPidText = await waitFile(pidFile, 8_000)
  assert.ok(childPidText, 'dummy child should report its pid')
  childPid = Number(childPidText.trim())
  await sleep(3_500) // 至少跨过一个 2s 检测周期
  assert.equal(isAlive(launcherPid), true, 'launcher must survive with a live parent')
  assert.equal(isAlive(childPid), true, 'backend child must not be killed while parent is alive')

  launcher.kill('SIGTERM')
  assert.equal(await waitExit(launcher, 8_000), true, 'launcher exits on SIGTERM')
  assert.equal(isAlive(childPid), false, 'backend child must not survive its launcher')
})

test('lifecycle: parent death terminates the owned child and exits the launcher', { timeout: 30_000 }, async t => {
  const home = await mkdtemp(join(tmpdir(), 'ark-lifecycle-parent-death-'))
  const childPidFile = join(home, 'child.pid')
  const launcherPidFile = join(home, 'launcher.pid')
  const childScript = await writeScript(home, 'child.mjs', longLivedChild)
  await writeScript(home, 'parent.mjs', dummyParent)
  const parent = spawnDummyParent(home, { childScript, launcherPidFile, childArgs: [`--child-pid-file=${childPidFile}`] })
  let childPid = null
  let launcherPid = null
  t.after(async () => {
    await runCleanups('parent-death lifecycle', [
      async () => { await terminateTestPid(parent.pid) },
      async () => {
        if (launcherPid === null) {
          const text = await readOptionalPidFile(launcherPidFile)
          if (text) launcherPid = Number(text.trim())
        }
        await terminateTestPid(launcherPid)
      },
      async () => {
        if (childPid === null) {
          const text = await readOptionalPidFile(childPidFile)
          if (text) childPid = Number(text.trim())
        }
        await terminateTestPid(childPid)
      },
      async () => { await rm(home, { recursive: true, force: true }) },
    ])
  })

  const childPidText = await waitFile(childPidFile, 8_000)
  const launcherPidText = await waitFile(launcherPidFile, 8_000)
  assert.ok(childPidText, 'dummy child should report its pid')
  assert.ok(launcherPidText, 'dummy parent should report the launcher pid')
  childPid = Number(childPidText.trim())
  launcherPid = Number(launcherPidText.trim())

  parent.kill('SIGKILL') // 模拟 UI crash
  assert.equal(await waitExit(parent, 5_000), true, 'dummy parent must die')
  assert.equal(await waitPidDead(childPid, 12_000), true, 'backend child must not orphan after parent death')
  assert.equal(await waitPidDead(launcherPid, 12_000), true, 'launcher must not orphan after parent death')
})

test('lifecycle: launcher SIGTERM terminates the owned child', { timeout: 30_000 }, async t => {
  const home = await mkdtemp(join(tmpdir(), 'ark-lifecycle-term-'))
  const pidFile = join(home, 'child.pid')
  const childScript = await writeScript(home, 'child.mjs', longLivedChild)
  const launcher = launch(home, { parentPid: process.pid, childScript, childArgs: [`--child-pid-file=${pidFile}`] })
  let childPid = null
  const launcherPid = launcher.pid
  t.after(async () => {
    await runCleanups('launcher-term lifecycle', [
      async () => { await terminateTestPid(launcherPid) },
      async () => {
        if (childPid === null) {
          const text = await readOptionalPidFile(pidFile)
          if (text) childPid = Number(text.trim())
        }
        await terminateTestPid(childPid)
      },
      async () => { await rm(home, { recursive: true, force: true }) },
    ])
  })

  const childPidText = await waitFile(pidFile, 8_000)
  assert.ok(childPidText, 'dummy child should report its pid')
  childPid = Number(childPidText.trim())

  launcher.kill('SIGTERM')
  assert.equal(await waitExit(launcher, 8_000), true, 'launcher exits on SIGTERM')
  assert.equal(isAlive(childPid), false, 'child must exit together with the launcher')
})

test('lifecycle: launcher reaps a TERM-resistant child before the UI outer deadline', { timeout: 30_000 }, async t => {
  const home = await mkdtemp(join(tmpdir(), 'ark-lifecycle-stubborn-'))
  const pidFile = join(home, 'child.pid')
  const childScript = await writeScript(home, 'stubborn-child.mjs', stubbornChild)
  const launcher = launch(home, {
    parentPid: process.pid,
    childScript,
    childArgs: [`--child-pid-file=${pidFile}`],
  })
  let childPid = null
  t.after(async () => {
    await runCleanups('stubborn-child lifecycle', [
      async () => { await terminateTestPid(launcher.pid) },
      async () => {
        if (childPid === null) {
          const text = await readOptionalPidFile(pidFile)
          if (text) childPid = Number(text.trim())
        }
        await terminateTestPid(childPid)
      },
      async () => { await rm(home, { recursive: true, force: true }) },
    ])
  })

  const childPidText = await waitFile(pidFile, 8_000)
  assert.ok(childPidText, 'stubborn child should report its pid')
  childPid = Number(childPidText.trim())
  launcher.kill('SIGTERM')
  assert.equal(await waitExit(launcher, 6_000), true, 'launcher exits after its four-second child deadline')
  assert.equal(await waitPidDead(childPid, 1_000), true, 'TERM-resistant child is killed and reaped first')
})

test('lifecycle: child exit first reaps cleanly without double terminate', { timeout: 30_000 }, async t => {
  const home = await mkdtemp(join(tmpdir(), 'ark-lifecycle-child-first-'))
  const childScript = await writeScript(home, 'exit-child.mjs', 'process.exit(7)\n')
  const launcher = launch(home, { parentPid: process.pid, childScript })
  t.after(async () => {
    await runCleanups('child-first lifecycle', [
      async () => { await terminateTestPid(launcher.pid) },
      async () => { await rm(home, { recursive: true, force: true }) },
    ])
  })

  assert.equal(await waitExit(launcher, 8_000), true, 'launcher exits after its child')
  assert.equal(launcher.exitCode, 7, 'launcher propagates the child exit code')
})

test('lifecycle: parent-death and SIGTERM race still cleans up exactly once', { timeout: 30_000 }, async t => {
  const home = await mkdtemp(join(tmpdir(), 'ark-lifecycle-race-'))
  const childPidFile = join(home, 'child.pid')
  const launcherPidFile = join(home, 'launcher.pid')
  const termLog = join(home, 'terms.log')
  const childScript = await writeScript(home, 'child.mjs', longLivedChild)
  await writeScript(home, 'parent.mjs', dummyParent)
  const parent = spawnDummyParent(home, {
    childScript,
    launcherPidFile,
    childArgs: [`--child-pid-file=${childPidFile}`, `--term-log=${termLog}`],
  })
  let childPid = null
  let launcherPid = null
  t.after(async () => {
    await runCleanups('race lifecycle', [
      async () => { await terminateTestPid(parent.pid) },
      async () => {
        if (launcherPid === null) {
          const text = await readOptionalPidFile(launcherPidFile)
          if (text) launcherPid = Number(text.trim())
        }
        await terminateTestPid(launcherPid)
      },
      async () => {
        if (childPid === null) {
          const text = await readOptionalPidFile(childPidFile)
          if (text) childPid = Number(text.trim())
        }
        await terminateTestPid(childPid)
      },
      async () => { await rm(home, { recursive: true, force: true }) },
    ])
  })

  const childPidText = await waitFile(childPidFile, 8_000)
  const launcherPidText = await waitFile(launcherPidFile, 8_000)
  assert.ok(childPidText, 'dummy child should report its pid')
  assert.ok(launcherPidText, 'dummy parent should report the launcher pid')
  childPid = Number(childPidText.trim())
  launcherPid = Number(launcherPidText.trim())

  // 近同时触发两条路径：parent death 与 launcher SIGTERM。
  parent.kill('SIGKILL')
  try {
    if (!isOwnedTestPid(launcherPid)) throw new Error(`launcher PID file did not yield an owned positive PID: ${String(launcherPid)}`)
    process.kill(launcherPid, 'SIGTERM')
  } catch (error) {
    // parent-death 路径可能已抢先让 launcher 退出——该竞态是允许结果。
    if (error?.code !== 'ESRCH') throw error
  }

  assert.equal(await waitPidDead(childPid, 12_000), true, 'child must exit under the race')
  assert.equal(await waitPidDead(launcherPid, 12_000), true, 'launcher must exit under the race')
  const terms = await readFile(termLog, 'utf8')
  assert.equal(terms.split('\n').filter(Boolean).length, 1, 'child receives exactly one TERM')
})

test('lifecycle: launcher source carries no forbidden cleanup patterns', () => {
  const source = readFileSync(startMjs, 'utf8')
  const backendProcess = readFileSync(backendProcessSwift, 'utf8')
  for (const banned of ['killall', 'pkill', 'lsof']) {
    assert.ok(!source.includes(banned), `launcher source must not contain ${banned}`)
  }
  assert.ok(source.includes('--parent-pid'), 'launcher accepts the UI parent pid')
  assert.ok(source.includes('shutdownOnce'), 'launcher owns one shutdown path')
  assert.ok(source.includes('process.ppid'), 'launcher watches its own parent identity')
  assert.match(source, /}, 4_000\)/, 'launcher child deadline is four seconds')
  assert.match(backendProcess, /\.now\(\) \+ 7/, 'UI outer launcher deadline is seven seconds')
})
