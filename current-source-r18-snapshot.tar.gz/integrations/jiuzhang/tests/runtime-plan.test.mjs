import assert from 'node:assert/strict'
import { mkdtemp, readFile, rm } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join, resolve } from 'node:path'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { fileURLToPath } from 'node:url'
import test from 'node:test'
import { createArkRuntimePlan } from '../src/runtime-plan.mjs'

const execFileAsync = promisify(execFile)
const repositoryRoot = resolve(fileURLToPath(new URL('../../..', import.meta.url)))
const required = [
  '@deepseek-ai/dsh-deepseek-llm-api-extensions',
  '@deepseek-ai/dsh-host-plugin-inventory',
  '@deepseek-ai/dsh-native-api-runner',
  '@deepseek-ai/dsh-plugin-package-inventory-deepseek',
  '@deepseek-ai/dsh-session-log-deepseek',
  '@deepseek-ai/dsh-web-fetch-http',
]

test('current Ark runtime analysis maps its dedicated runner, security packages, and any forbidden reachability', async () => {
  const plan = await createArkRuntimePlan(repositoryRoot, { allowForbiddenAnalysis: true })
  const names = new Set(plan.packages.map(entry => entry.name))

  assert.deepEqual(plan.roots, ['@deepseek-ai/dsh-native-api-runner'])
  assert.equal(plan.target, 'macos-arm64')
  assert.deepEqual(plan.deferredPlatforms, ['win-x64'])
  assert.match(plan.sourceDigest, /^[a-f0-9]{64}$/)
  for (const name of required) assert.ok(names.has(name), `${name} must be in the current Ark closure plan`)
  assert.ok(names.has('@deepseek-ai/node-addon-landlock-run'), 'the portable Landlock seam remains in the closure')
  assert.equal(
    names.has('@deepseek-ai/dsh-sandbox-windows-acl'),
    false,
    'the macos-arm64 plan must omit the win32-only optional ACL backend',
  )
  assert.equal(names.has('@deepseek-ai/node-addon-landlock-run-linux-arm64'), false)
  assert.equal(names.has('@deepseek-ai/node-addon-landlock-run-linux-x64'), false)
  if (plan.forbiddenPackages.length === 0) {
    await assert.doesNotReject(createArkRuntimePlan(repositoryRoot))
  } else {
    assert.deepEqual(plan.forbiddenPackages, [
      '@deepseek-ai/dsh',
      '@deepseek-ai/dsh-headless',
    ])
    assert.ok(plan.forbiddenChains.every(chain => (
      chain.startsWith('@deepseek-ai/dsh-native-api-runner -> ')
      && chain.includes('@deepseek-ai/dsh-sdk-client')
    )))
    await assert.rejects(createArkRuntimePlan(repositoryRoot), /reaches forbidden packages/)
  }
})

test('plan-only pack writes an exact current-source closure receipt without building or packing', async () => {
  const parent = await mkdtemp(join(tmpdir(), 'ark-runtime-plan-only-'))
  const output = join(parent, 'output')
  try {
    const analysis = await createArkRuntimePlan(repositoryRoot, { allowForbiddenAnalysis: true })
    const command = execFileAsync(process.execPath, [
      'integrations/jiuzhang/src/pack-runtime.mjs',
      '--out', output,
      '--plan-only',
    ], { cwd: repositoryRoot })
    if (analysis.forbiddenPackages.length > 0) {
      await assert.rejects(command, /reaches forbidden packages/)
    } else {
      const result = await command
      assert.match(result.stdout, /Ark current runtime plan:/)
      const plan = JSON.parse(await readFile(join(output, 'closure-plan.json'), 'utf8'))
      assert.match(plan.sourceDigest, /^[a-f0-9]{64}$/)
      assert.ok(plan.requiredFiles.some(entry => entry.path === 'jiuzhang/profile/forbidden-runtime-packages.json'))
    }
  } finally {
    await rm(parent, { recursive: true, force: true })
  }
})
