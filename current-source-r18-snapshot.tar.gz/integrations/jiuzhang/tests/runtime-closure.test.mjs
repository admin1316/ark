import assert from 'node:assert/strict'
import { copyFile, mkdir, mkdtemp, readFile, rm, symlink, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { dirname, join, resolve } from 'node:path'
import test from 'node:test'
import { fileURLToPath } from 'node:url'
import { assertArkRuntimeClosure, packageJavaScriptEntries } from '../src/runtime-closure.mjs'

const integrationRoot = resolve(fileURLToPath(new URL('..', import.meta.url)))
const policy = join(integrationRoot, 'profile/forbidden-runtime-packages.json')
const policyDocument = JSON.parse(await readFile(policy, 'utf8'))

async function stageRuntime() {
  const root = await mkdtemp(join(tmpdir(), 'ark-runtime-closure-'))
  for (const relative of policyDocument.requiredFiles) {
    const source = relative.startsWith('jiuzhang/profile/')
      ? join(integrationRoot, 'profile', relative.slice('jiuzhang/profile/'.length))
      : join(integrationRoot, 'src', relative)
    const destination = join(root, relative)
    await mkdir(dirname(destination), { recursive: true })
    await copyFile(source, destination)
  }
  for (const name of policyDocument.required) {
    const packageRoot = join(root, 'node_modules', ...name.split('/'))
    await mkdir(packageRoot, { recursive: true })
    await writeFile(join(packageRoot, 'package.json'), JSON.stringify({ name }))
  }
  const entry = join(root, 'node_modules/@deepseek-ai/dsh-native-api-runner/lib/bin.js')
  await mkdir(dirname(entry), { recursive: true })
  await writeFile(entry, '#!/usr/bin/env node\n')
  return root
}

test('Ark runtime closure accepts the dedicated entry and scans pnpm package identities', async () => {
  const root = await stageRuntime()
  try {
    await writeFile(join(root, 'node_modules/.modules.yaml'), 'hoistPattern: []\n')
    assert.deepEqual(await assertArkRuntimeClosure(root, policy), { packageCount: policyDocument.required.length })
    const forbidden = join(root, 'node_modules/.pnpm/web-app/node_modules/@deepseek-ai/dsh-web-app')
    await mkdir(forbidden, { recursive: true })
    await writeFile(join(forbidden, 'package.json'), JSON.stringify({ name: '@deepseek-ai/dsh-web-app' }))
    await assert.rejects(assertArkRuntimeClosure(root, policy), /dsh-web-app/)
  } finally {
    await rm(root, { recursive: true, force: true })
  }
})

test('Ark runtime closure rejects a missing current required package or product asset', async () => {
  const root = await stageRuntime()
  try {
    await rm(join(root, 'node_modules/@deepseek-ai/dsh-session-log-deepseek'), { recursive: true })
    await assert.rejects(
      assertArkRuntimeClosure(root, policy),
      /lacks required package identities: @deepseek-ai\/dsh-session-log-deepseek/,
    )

    await mkdir(join(root, 'node_modules/@deepseek-ai/dsh-session-log-deepseek'), { recursive: true })
    await writeFile(
      join(root, 'node_modules/@deepseek-ai/dsh-session-log-deepseek/package.json'),
      JSON.stringify({ name: '@deepseek-ai/dsh-session-log-deepseek' }),
    )
    await rm(join(root, 'runtime.mjs'))
    await assert.rejects(assertArkRuntimeClosure(root, policy), /lacks required current-source asset: .*runtime\.mjs/)
  } finally {
    await rm(root, { recursive: true, force: true })
  }
})

test('Ark runtime closure follows direct package links and rejects node_modules bypass siblings', async () => {
  const root = await stageRuntime()
  try {
    const storePackage = join(root, 'node_modules/.pnpm/ui/node_modules/@deepseek-ai/dsh-client-ui-layout')
    await mkdir(storePackage, { recursive: true })
    await writeFile(join(storePackage, 'package.json'), JSON.stringify({ name: '@deepseek-ai/dsh-client-ui-layout' }))
    const direct = join(root, 'node_modules/@deepseek-ai/dsh-client-ui-layout')
    await symlink('../.pnpm/ui/node_modules/@deepseek-ai/dsh-client-ui-layout', direct)
    await assert.rejects(assertArkRuntimeClosure(root, policy), /dsh-client-ui-layout/)

    await rm(direct)
    await rm(join(root, 'node_modules/.pnpm'), { recursive: true })
    await mkdir(join(root, 'node_modules.interrupted-v82-offline'))
    await assert.rejects(assertArkRuntimeClosure(root, policy), /node_modules\.interrupted-v82-offline/)
  } finally {
    await rm(root, { recursive: true, force: true })
  }
})

test('Ark runtime closure rejects every browser-client package family member', async () => {
  for (const name of [
    '@deepseek-ai/dsh',
    '@deepseek-ai/dsh-client-web',
    '@deepseek-ai/dsh-client-test-runtime',
    '@deepseek-ai/dsh-client-connection',
    '@deepseek-ai/dsh-client-api-remotes',
  ]) {
    const root = await stageRuntime()
    try {
      const packageRoot = join(root, 'node_modules/.pnpm/client/node_modules', ...name.split('/'))
      await mkdir(packageRoot, { recursive: true })
      await writeFile(join(packageRoot, 'package.json'), JSON.stringify({ name }))
      await assert.rejects(assertArkRuntimeClosure(root, policy), new RegExp(name.slice(name.lastIndexOf('/') + 1)))
    } finally {
      await rm(root, { recursive: true, force: true })
    }
  }
})

test('Ark runtime closure rejects forbidden dependency edges even when the target is absent', async () => {
  const root = await stageRuntime()
  try {
    const packageRoot = join(root, 'node_modules/.pnpm/owner/node_modules/@deepseek-ai/dsh-native-owner')
    await mkdir(packageRoot, { recursive: true })
    await writeFile(join(packageRoot, 'package.json'), JSON.stringify({
      name: '@deepseek-ai/dsh-native-owner',
      optionalDependencies: {
        '@deepseek-ai/dsh-client-web': '0.1.1-rc.2',
      },
    }))
    await assert.rejects(
      assertArkRuntimeClosure(root, policy),
      /dsh-native-owner -> @deepseek-ai\/dsh-client-web/,
    )
  } finally {
    await rm(root, { recursive: true, force: true })
  }
})

test('Ark runtime closure rejects an exported first-party entry that plain Node cannot parse', async () => {
  const root = await stageRuntime()
  try {
    const packageRoot = join(root, 'node_modules/@deepseek-ai/dsh-syntax-fixture')
    await mkdir(join(packageRoot, 'lib'), { recursive: true })
    await writeFile(join(packageRoot, 'package.json'), JSON.stringify({
      name: '@deepseek-ai/dsh-syntax-fixture',
      type: 'module',
      main: 'lib/index.js',
      exports: {
        '.': './lib/index.js',
        './broken': './lib/broken.js',
      },
    }))
    await writeFile(join(packageRoot, 'lib/index.js'), 'export const ok = true\n')
    await writeFile(join(packageRoot, 'lib/broken.js'), 'class Broken { @Remote("run") run() {} }\n')
    await assert.rejects(
      assertArkRuntimeClosure(root, policy),
      /unparseable JavaScript entry @deepseek-ai\/dsh-syntax-fixture:lib\/broken\.js/,
    )
  } finally {
    await rm(root, { recursive: true, force: true })
  }
})

test('Ark runtime syntax inventory rejects an entry that escapes its package', () => {
  assert.throws(
    () => packageJavaScriptEntries({ main: '../outside.js' }),
    /unsafe JavaScript entry: \.\.\/outside\.js/,
  )
})
