/** Probe one test-owned PID without changing process state. */
export const processIsAlive = (
  pid,
  signalProcess = process.kill.bind(process),
) => {
  if (!Number.isSafeInteger(pid) || pid <= 1) return false
  try {
    signalProcess(pid, 0)
    return true
  } catch (error) {
    if (error?.code === 'ESRCH') return false
    throw error
  }
}

/** Signal one already-owned safe PID, tolerating only a vanished process. */
export const signalOwnedProcess = (
  pid,
  signal,
  signalProcess = process.kill.bind(process),
) => {
  if (!Number.isSafeInteger(pid) || pid <= 1) {
    throw new Error(`cannot signal unsafe test pid: ${String(pid)}`)
  }
  try {
    signalProcess(pid, signal)
    return true
  } catch (error) {
    if (error?.code === 'ESRCH') return false
    throw error
  }
}

export class CleanupTimeoutError extends Error {
  constructor(label, timeoutMs) {
    super(`${label} cleanup timed out after ${String(timeoutMs)}ms`)
    this.name = 'CleanupTimeoutError'
  }
}

export const withCleanupDeadline = async (label, timeoutMs, operation) => {
  let timer
  const controller = new AbortController()
  try {
    return await Promise.race([
      Promise.resolve().then(() => operation(controller.signal)),
      new Promise((_, reject) => {
        timer = setTimeout(() => {
          const error = new CleanupTimeoutError(label, timeoutMs)
          reject(error)
          controller.abort(error)
        }, timeoutMs)
      }),
    ])
  } finally {
    if (timer !== undefined) clearTimeout(timer)
  }
}

export const runCleanupSteps = async (label, primaryFailures, steps) => {
  const failures = [...primaryFailures]
  for (const step of steps) {
    try {
      await withCleanupDeadline(step.label, step.timeoutMs, step.run)
    } catch (error) {
      failures.push(error)
    }
  }
  if (failures.length === 1) throw failures[0]
  if (failures.length > 1) throw new AggregateError(failures, `${label}: primary and cleanup failures`)
}
