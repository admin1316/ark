const childExited = child => child.exitCode !== null || child.signalCode !== null

const validIdentity = identity => (
  Number.isSafeInteger(identity?.pid) && identity.pid > 1
    && Number.isSafeInteger(identity.parentPid) && identity.parentPid >= 0
    && typeof identity.started === 'string' && identity.started !== ''
)

export const retainedBackendIsAlive = (rows, state, backend) => {
  if (!validIdentity(state?.launcher) || !validIdentity(backend)
    || backend.parentPid !== state.launcher.pid) return false
  const currentBackend = rows.find(process => (
    process.pid === backend.pid && process.started === backend.started
  ))
  if (currentBackend === undefined) return false
  if (currentBackend.parentPid === 1) return true
  if (currentBackend.parentPid !== state.launcher.pid) return false
  return rows.some(process => (
    process.pid === state.launcher.pid && process.started === state.launcher.started
  ))
}

export const createInstallProcessOwnership = readProcessTable => {
  const states = new WeakMap()

  const capture = async child => {
    const retained = states.get(child)
    if (retained !== undefined) {
      if (retained.capturePromise !== undefined) return retained.capturePromise
      if (retained.captureError !== undefined) throw retained.captureError
      return retained
    }
    if (childExited(child)) return undefined
    const launcherPid = child.pid
    const state = {
      launcherPid,
      launcher: undefined,
      backends: [],
      captureError: undefined,
      capturePromise: undefined,
      cleanupPromise: undefined,
      cleaned: false,
    }
    states.set(child, state)
    const pending = (async () => {
      try {
        if (!Number.isSafeInteger(launcherPid) || launcherPid <= 1) {
          throw new Error(`launcher handle did not expose a safe pid: ${String(launcherPid)}`)
        }
        const rows = await readProcessTable()
        const launcher = rows.find(process => process.pid === launcherPid)
        if (!validIdentity(launcher)) {
          throw new Error(`cannot capture launcher start identity for pid ${String(launcherPid)}`)
        }
        if (childExited(child)) throw new Error('launcher exited during ownership capture')
        state.launcher = launcher
        state.backends = rows.filter(process => (
          process.parentPid === launcherPid && validIdentity(process)
        ))
        return state
      } catch (error) {
        state.captureError = error
        throw error
      }
    })()
    state.capturePromise = pending
    return pending
  }

  const cleanup = (child, run) => {
    const state = states.get(child)
    if (state?.cleanupPromise !== undefined) return state.cleanupPromise
    if (state === undefined && childExited(child)) return Promise.resolve()
    const pending = Promise.resolve().then(() => run(state)).finally(() => {
      if (state !== undefined) state.cleaned = true
    })
    if (state !== undefined) state.cleanupPromise = pending
    return pending
  }

  return { capture, cleanup, get: child => states.get(child) }
}
