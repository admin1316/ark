# Independent source-finding review 2

Model: GPT-5.6 Sol
Reasoning: High
Agent: 01a0730f-1b7b-7972-bc2d-171e6cf81eb1
Mode: fresh read-only context
Author has NOT changed Native Events source.

# COVERAGE SOURCE FINDING: REVISE

`node:assert/strict` 可以表达该内部不变量，但在当前硬约束下，不能证明它是完整、行为保持的 coverage 修复；若仅用它消除本文件中的未覆盖分支，属于 gate gaming，不能标记 `VERIFIED`。

关键判断：

- 精确清单中的源码 SHA `5e1303…f65` 与当前 [index.ts](/private/tmp/ark-r18/packages/host/native-events/src/index.ts:272) 完全一致。
- `FrameQueue` 只有两个调用点，均为无参数 `new FrameQueue()`：[mux](/private/tmp/ark-r18/packages/host/native-events/src/index.ts:739) 和 [host](/private/tmp/ark-r18/packages/host/native-events/src/index.ts:862)。因此构造参数及非法 limit 检查确为当前产品不可达死代码，可安全改成固定无参构造并删除该校验。
- ring slot 的 `undefined` 分支在有效 owner 行为下不可达：slot 写入先于 `size++`，读取和清空发生在同一同步 `take()` 中，单消费者且 JS 不会在这些同步语句之间抢占。若要触发，只能篡改 `buffer/head/size`、新增测试 seam，或故意破坏实现；均被本轮规则禁止。

Assertion 的具体影响：

```ts
import assert from 'node:assert/strict'

assert(queued !== undefined, 'native event queue ring invariant failed')
```

- 成功路径不会创建 `Error`/`AssertionError`；但每次 dequeue 会增加一次 assertion 函数调用和布尔判断。相比当前内联 `if`，可能有额外调用开销，但没有“每帧构造 Error”的确定性堆分配。
- 失败路径不再抛普通 `Error`，而是 `AssertionError`，通常带 `code: 'ERR_ASSERTION'`。当前普通 `Error` 没有 `code`，会由 [failureFrame](/private/tmp/ark-r18/packages/host/connection/src/websocket-downlink.ts:50) 归一为 `EVENT_STREAM_FAILED`；换成 assertion 后，线路上的 `stream/error.error.code` 会变成 `ERR_ASSERTION`。这不是严格的公共失败语义保持。
- `assert(condition, new Error(...))` 能继续抛普通 `Error`，但参数在调用前求值，会为每个成功 dequeue 分配并捕获一次 Error stack，明确不可接受。
- 复用预创建的 `Error` 虽避免逐帧分配，却会产生陈旧 stack、共享异常实例和错误的故障定位，也不等价于当前在故障现场创建的新 `Error`。
- 更重要的是，任何允许的测试都只能执行 assertion 的成功路径；不能证明实际 ring hole 会触发保护。单独测试 Node assertion 或做源码字符串检查也不能证明产品 guard。

允许的最小范围：

1. 删除 [构造器参数与非法 limit 分支](/private/tmp/ark-r18/packages/host/native-events/src/index.ts:282)，保留现有固定常量和单一 owner。
2. 通过现有事件源/投影 seam 增加真实可达测试：
   - 用不可 JSON 编码的 projection 值触发 `EVENT_FRAME_ENCODING_FAILED`。
   - 用预先 aborted 的 source signal 证明立即结束并执行 listener cleanup。
   - 用 `toJSON()` 同步触发嵌套编码失败后再抛错，证明重入的第二次 `fail()` 不覆盖首个失败。
   - 经 owner 投影路径执行超过 `NATIVE_EVENT_QUEUE_MAX_FRAMES` 次交替 enqueue/dequeue，验证完整 wraparound、FIFO、继续入队和 byte accounting；不得直接改 private ring 字段。
3. 不新增 ignore、exclude、阈值修改、依赖、配置、测试工厂或 production 测试开口。

残余 blocker：上述范围能关闭所有真实可达缺口，但不能在现有硬规则下同时覆盖并验证 ring-hole 失败分支。除非另有可证明、行为保持且让 hole 在结构上不可表示的队列设计，否则 assertion 替换不能作为完整修复批准。

本轮严格只读；未写文件、未运行测试、构建、网络或 LIVE。

