# Independent Adversarial Review — Settings "settings write-path integrity + revision settlement", R18 coverage-gate closure

Reviewer: Sol High (independent)
Date: 2026-09-06
Scope: `packages/settings/settings/**` + its describing docs/notes only, per the R18 review protocol.
Source workspace: `/private/tmp/ark-r18` · Evidence root: `/private/tmp/ark-final-test-candidate-z0n2sQ`

---

## Verdict: REJECTED

> **[Supplemental, 2026-09-06 later] Post-remediation re-verification: VERIFIED.** The defect this rejection was grounded on (pragma (d)) was remediated per option 1 and re-verified from the artifacts — see "Supplemental review: remediation re-verification" at the end of this document. The original findings below are retained as the record of what was rejected and why; line references in sections 1–9 describe the pre-remediation tree unless marked.

Narrow but decisive ground: one of the four `/* v8 ignore next */` justifications added this round — the one covering `settle()`'s ternary alternate (`packages/settings/settings/src/index.ts:828-831`) — is falsifiable at runtime through the package's **public API**. I reproduced the "unreachable" arm executing, and it returns a **wrong answer** when it does (`settle()` resolved `true` for a revision whose owner callback subsequently failed, contradicting the shipped README contract). Per the review protocol ("if you find a reachable path through any of them, this is a REJECTED finding"), the coverage-gate closure cannot be accepted as sealed.

Scope of the rejection, so it is not over-read:

- The other **three** pragmas (index.ts:374, :585, :590) — **CONFIRMED** unreachable; I attempted to refute each and failed.
- The coverage-gate closure **mechanics** are otherwise sound: the pre-round gap decomposes exactly as claimed (1 statement + 1 function at the base-default getter, 8 branches = 4 pragma sites + 4 sites closed by two genuine new tests), the manifest delta pre→post is exactly the three claimed files, this round's `src/index.ts` delta is exactly the four pragma comment lines (semantic nullity holds), all receipts are intact with real exit codes, prior failure evidence was not deleted, endpoint-transaction replay is green, and docs are consistent with the shipped semantics (one pre-existing excerpt drift noted, non-blocking).
- The defect the item set out to fix (early success + later false in the write path) **is** fixed for every path reachable from the tested, JSON-data-shaped usage. The refutation is an edge of the fix's own invariant, reachable only when a caller passes an accessor-bearing value as `base` (or a schema returns one) — unusual, but inside the public contract, and precisely the class of value the write boundary's JSON discipline does *not* screen (`base` is never `cloneJsonShaped`-walked).

---

## 1. Workspace and freeze identity — VERIFIED

- `git rev-parse HEAD` = `84ae44c98c94bac19c29cd70516dc10a01af170b` (matches required HEAD), branch `main`.
- `repair-settings-coverage-fix-pre/identity.json`: HEAD `84ae44c9…`, 2026-09-06T17:48:31Z; `…-post/identity.json`: same HEAD, 2026-09-06T18:01:20Z, `status_sha256` identical (`3eda70af…`) — same working-tree status, no stray files added/removed.
- Manifest diff pre→post (computed by me from `manifest.json`): **exactly 3 changed paths, 0 added, 0 removed**:
  - `packages/settings/settings/src/index.ts` (`84a303cd…` → `bfe14ab6…`)
  - `packages/settings/settings/tests/memory.ts` (`3b9f12f7…` → `b673c4bd…`)
  - `packages/settings/settings/tests/settings.spec.ts` (`a6049cdf…` → `cada2473…`)
- Gate/config stability across the whole span (docs-pre freeze → post freeze, sha256 manifest comparison): `vitest.config.ts`, `vitest.shared.ts`, `scripts/run-gates.ts`, root `package.json`, `pnpm-lock.yaml`, `packages/settings/settings/package.json`, `tsconfig.json`, `tsdown.config.ts` — all byte-identical. No dependency, threshold, or timeout-configuration change.

## 2. The four unreachability claims

### (a) `settlesBefore` timer guard — index.ts:374-376 — CONFIRMED

```ts
let timer: ReturnType<typeof setTimeout> | undefined
const timeout = new Promise<false>((resolve) => { timer = setTimeout(resolve, timeoutMs, false); timer.unref() })
try { return await Promise.race([operation.then(() => true), timeout]) }
finally { /* v8 ignore next */ if (timer !== undefined) clearTimeout(timer) }
```

The Promise executor runs synchronously during construction (ES spec), so `timer` is assigned before `try` begins. The only escape is `setTimeout` returning a falsy value or throwing *before* assignment — both excluded by the Node platform contract (`setTimeout` always returns a `Timeout`); nothing in the package or in the shared test setup (`scripts/test-invariants.ts` — no global/stub patching, verified by grep) monkey-patches it. Note `timer.unref()` throwing would still leave `timer` assigned (assignment precedes it), so even that path keeps the guard true. False arm unreachable. CONFIRMED.

### (b) Late-settle delete after quiescence timeout — index.ts:585-587 — CONFIRMED

Claim: a timed-out owner blocks replacement, so it still owns the namespace when its late settle fires; the guard `this.registrations.get(ns) === registration` can never be false.

Verified from the code: `this.registrations` is mutated at exactly three sites (grep): set at :555 (effect mount), delete at :586 (late settle) and :591 (clean dispose) — both deletes belong to this same registration's disposer closure, and within one disposer invocation :586/:591 are mutually exclusive branches (the late callback only registers on the timeout branch, which `throw`s at :588 before :591 is reachable). Replacement is blocked while the timed-out registration exists: `register()` at :527-532 throws `SettingsRegistrationQuiescenceError` when `existing.quiescenceTimedOut`. Service dispose never clears the map. Nothing else can remove or replace the slot between timeout and late settle, so the guard is always true and the false arm is unreachable. CONFIRMED.

### (c) Clean-dispose delete — index.ts:590-591 — CONFIRMED

Claim: the registering disposer is the sole deleter of its own registration.

Same three-mutation-site evidence as (b). The remaining question was whether a cordis effect disposer can run twice (a second run after the late delete would see a foreign slot). It cannot: `node_modules/@deepseek-ai/cordis/lib/index.js` (v4.0.1), `fiber.effect()` (~:1168) builds `dispose` with `if (disposing) return disposalTask` and `disposables.splice(0)` — single-shot by construction; a restarted fiber creates a *new* effect via a new `register()` call (and `register()` throws while any slot exists). No second run, no foreign deleter → the guard's false arm is unreachable. CONFIRMED.

### (d) `settle()` ternary alternate — index.ts:828-831 — REFUTED (runtime-reproduced)

Claim: "every revision bump installs its settlement in the same synchronous commit … so settlementRevision never trails revision at settle() time."

The *structural* premise is true and I verified it: `bumpRevision` is immediately followed by `commit` in both paths (write :978-981; publish :1018-1019), publish's resolve-throw `continue`s before the bump (:1013-1017), and `commit` installs `settlementRevision`/`settlement` before emitting (:1093-1094 equal-value branch, :1123-1126 changed branch). There is no `await` between bump and install.

But the invariant is observably violated for user code invoked from inside `commit`'s own equality walk. `commit`'s first statement `deepEqualJson(next, prev)` (:1091) executes **after** the bump and **before** the settlement install, and `deepEqualJson` reads value properties — including accessors. `base` is caller-supplied, is never passed through the `cloneJsonShaped` JSON boundary, and survives resolution verbatim (`mergeLayers` returns `under` as-is when the section is undefined; `z.any()` passes input through — verified in `@deepseek-ai/schemastery/lib/index.mjs:345`). An enumerable accessor on `base` therefore gets read inside `commit` at exactly the vulnerable instant.

I reproduced it twice on the shipped source via the evidence runner (cwd = `/private/tmp/ark-r18`, no source-tree modification):

- `review-settings-probe-d5` (receipt rc=0, log sha256 `814d4d41d119414b965d9cab4fc8b9ea05bc452f78673ae4baeb1ea2b93cde87`)
- `review-settings-probe-d-public2` (receipt rc=0, log sha256 `22f512d7305ed411c1f986f950ca1f41ecdc5f2ed4572b222925fd4490f46dae`) — hardened variant, **public API only** (`new Context()` → `ctx.plugin(ProbeProvider)` → `provider.register(ns, z.any(), { base })` → `scope.watch(...)` → `provider.update(...)`); probe script: `/private/tmp/ark-final-test-candidate-z0n2sQ/review-settings-scratch/review-settings-probe-d-public.mjs`

Interleaving (from the recorded log):

1. t=14 register: accessor `base` resolves; `deepFreeze` reads it (read 1).
2. t=15 `update(ns,{zz:'y'})` → queue run → resolve spreads base (read 2, still pre-bump).
3. `persist` completes → `document[ns]` set (:977) → `bumpRevision` :0→:1 (:979).
4. `commit` :1091 `deepEqualJson(next, prev)` reads `prev.k` (read 3) — **the accessor fires, re-entering `settle(ns, 1)`**: revision check passes (revision already bumped), `settlementRevision` is still 0 → **ternary alternate taken** → `Promise.resolve(true)`.
5. t=15 `reentrant-settle-resolved: true` — `settle()` has returned success for revision 1.
6. `commit` continues: values differ → changed branch → watcher outcome queued → the watcher fails at t=116 (`watcher-failing`) → real settlement for revision 1 = **false**; `posthoc-settle-resolved: false` at t=270.

Result: `settle(ns, 1)` answered `true` while that revision's owner callback had not yet run and ultimately **failed**. This is precisely the "early success + later false" defect class the item exists to eliminate, reintroduced through the suppressed arm, and it contradicts the shipped package contract (`packages/settings/settings/README.md:18` — "It returns false on callback failure"). REFUTED.

(For completeness: read-order counter-latches confirm the pre-bump reads — register `deepFreeze`, `mergeLayers` spread — never reach the arm; the sole channel is `commit`'s post-bump accessor read. The same channel exists on the publish path, where `prev` is the previously installed resolved value.)

## 3. Coverage-gap closure mechanics — VERIFIED (mechanics), tainted by (d)

Pre-round failure `repair-settings-sealed-coverage` (rc=1, thresholds enforced — the log carries the four "does not meet global threshold (100%)" ERROR lines; thresholds are `perFile: true, statements/branches/functions/lines: 100` in `vitest.config.ts:127-135`) reports for `src/index.ts`: statements 426/427, branches 289/297, functions 93/94, lines 364/365, uncovered line 448. Its `coverage-final.json` enumerates the uncovered regions exactly:

- stmt 132 @448 + fn 21 `registrationQuiescenceTimeoutMs` @447 — the base-default getter (`return 5_000`, :448-450).
- 8 branches: `if`@374 (timer guard), `cond-expr`@544 (register `redact` option ternary), `if`@584 (late-settle delete), `if`@588 (clean-dispose delete), `cond-expr`@825 (settle ternary), `cond-expr`@1292/1293/1294 (the three `installSettingsSection` hook ternaries).

Closure accounting (pre 427/297/94/365 → post 420/289/94/361): pragmas remove exactly 7 statements + 8 branches + 4 lines + 0 functions — matching the four pragma sites and nothing else. The remaining four branch sites and the line-448 function are closed by real tests:

- `tests/memory.ts:22,45,56-58` — fixture defers via `this.quiescenceTimeoutMs ?? super.registrationQuiescenceTimeoutMs`; the fixture's former default was also 5_000 (base default :449 is 5_000), so behavior is identical and every unpinned test now exercises the base getter. No test relied on a differing fixture default (the field is private; explicit pins unaffected). Behavior-identical claim CONFIRMED.
- `tests/settings.spec.ts:210` "honors a register-supplied redact when describing secrets" — drives `registration.redact ?? schema-fallback` (:640-647) on both arms, asserting owner-redacted value/base/user plus secrets and that the unredacted describe keeps the resolved value. Genuine behavior pin.
- `tests/settings.spec.ts:1291` "wires validate, validateWrite, and redact hooks through the consumer registration" — exercises `installSettingsSection` hook plumbing (:1296-1298) end-to-end: resolution-time `validate` rejection, pre-persist `validateWrite` rejection, non-poisoning of the serialized queue, persisted-section assertion (`provider.persisted == [{theme:'live'}]`), and hook `redact` over descriptor layers. Genuine pin on previously untested plumbing that the provider-transaction fix relies on. Not gate-gaming.

My independent coverage run (`review-settings-coverage`, rc=0, log sha256 `e574e3ecbb22b089cfd416f0931a055018fba348a8fa60fa997faeed958c2e87`) reproduces 100% (420/420, 289/289, 94/94, 361/361) with **zero** uncovered regions in `coverage-final.json`; the previously test-closed branches show both arms exercised (`[229,2]` @545; `[3,1]` ×3 @1296-1298). The 100% is real — but it is achieved partly by suppressing a branch I demonstrated reachable, so the gate's "no reachable uncovered code" property does not hold.

## 4. Semantic nullity of this round's src change — VERIFIED

I reconstructed the pre-round `src/index.ts` from HEAD blob + `repair-settings-docs-pre/diff.patch` (scratch git repo, `git apply`) and diffed against current, then reconstructed the same file from `repair-settings-coverage-fix-pre/diff.patch` to isolate this round:

- docs-pre → current: 4 pragma comment lines + a comment-only JSDoc edit in the `settle()` docblock (:810-818 — added sentence "The promise is bound before synchronous document notification."; `@param revision` wording broadened). All comment lines.
- coverage-fix-pre → current (this round alone): **exactly the four `/* v8 ignore next */` lines** at :374, :585, :590, :828. Zero executable delta.

## 5. Receipt audit — VERIFIED

Every receipt re-hashed; all `log_sha256` match file contents; all exit codes are `real_exit_code` from the runner (which records the child's close event directly). Prior failure evidence intact (the runner writes with `wx` — no overwrite possible — and nothing was deleted):

| evidence | rc | note |
|---|---|---|
| repair-settings-before | 1 | baseline (coverage run) |
| repair-settings-initial | 1 | 1-failure baseline (settings.spec) |
| repair-settings-initial-lint | 1 | later fixed |
| repair-settings-matrix-before | 1 | |
| repair-settings-adjusted | 0 | |
| repair-settings-adjusted-lint | 1 | later fixed |
| repair-settings-final-lint / -final-typecheck | 0 / 0 | empty logs (sha of empty string, expected) |
| repair-settings-pair-write / -pair-check | 0 / 0 | README + note, 07:47:48 / 07:48:18 |
| repair-settings-sealed-behavior | 0 | 505 tests, 18 files |
| repair-settings-sealed-coverage | 1 | the gap (line 448 + 8 branches) |
| coverage-fix-behavior | 0 | 507 tests, 18 files (505 + the 2 new tests) |
| coverage-fix-coverage | 0 | 100% ×4 |
| coverage-fix-lint | 0 | 4 files: index.ts, types.ts, settings.spec.ts, memory.ts |
| coverage-fix-typecheck | 0 | |

Docs stability: every doc/note file (`packages/settings/settings/README{,.zh,.i18n}.yaml`, `docs/subsystems/settings.*`, `docs/event-producer-consumer.*`, the note ×3) is byte-identical from `repair-settings-sealed-behavior-pre` (07:48:18.6, i.e. the pair-check instant) through `coverage-fix-post` and to the current tree. `docs/event-producer-consumer.*` and `docs/subsystems/settings.*` additionally unchanged since docs-pre; README ×3 and the note changed only at `pair-write --write` (07:47:48), *before* pair-check ran. "Docs finalized before this round; pair-check ran on the exact shipped content" — CONFIRMED.

## 6. Endpoint transaction replay — VERIFIED

`packages/llm/llm/tests` = 14 spec files + settings' 4 = the 18 files in both behavior seals. The replay inventory is present in `packages/llm/llm/tests/remote-coverage.spec.ts` (e.g. :1496 "replays committed and rolled-back terminal journals…", :1685 "detects a settings namespace disappearing during a prepared replay", :1782 "replays a committed transaction after revision advance…") and `remote.spec.ts:78`. All green in `repair-settings-coverage-fix-behavior` (507/507) and in my independent `review-settings-behavior` (rc=0, 507/507, log sha256 `ad4d7276f0082943f6de07dab6cd159ea2e97c3de0803e511a95cefee34af702`).

## 7. Docs vs shipped semantics — CONSISTENT (one pre-existing excerpt drift)

Verified against the code: settlement installed before `settings/document-updated` (commit :1093-1095/:1123-1129 before the fan-outs); document event precedes `settings/updated` (:1129 before :1136); a listener may `settle()` immediately; identical raw write retains the existing settlement (documentChanged=false skips the reset at :1092); new raw revision with unchanged resolved value settles true (:1093-1094); superseded fan-outs stop at :1069/:1138. README:18/:32, the note's "Revision settlement before notification" section, and `docs/event-producer-consumer.md` all match. This round's changes (comments + tests) invalidate no doc claim.

Non-blocking drift (pre-existing, not this round): `docs/subsystems/settings.md:270-283` embeds an API excerpt carrying the **older** `settle` JSDoc ("revision returned by the write's redacted descriptor") while src's JSDoc was broadened earlier in the R18 round to "exact revision from a descriptor or document notification". No semantic contradiction (the excerpt's wording is merely narrower), but the excerpt is stale relative to src.

## 8. Checks run (my own evidence entries)

All under the mandated `review-settings-` prefix, via the evidence runner (receipts with `real_exit_code` + verified log hashes):

- `review-settings-behavior` — rc=0, 507/507 — log sha256 `ad4d7276…f702`
- `review-settings-coverage` — rc=0, 100% ×4, 0 uncovered regions — log sha256 `e574e3ec…2e87`
- `review-settings-probe-d`, `-d2`, `-d3`, `-d4` — probe bring-up failures (module resolution / TS parameter properties / decorators), kept for the record
- `review-settings-probe-d5` — rc=0, first successful refutation run — log sha256 `814d4d41…cde87`
- `review-settings-probe-d-public`, `-d-public2` — public-API-only probe; `-d-public2` rc=0, refutation reproduced — log sha256 `22f512d7…46dae`

Free reads (no runner): freeze manifest/identity/diff.patch inspection; reconstruction of pre-round file states via HEAD blob + `git apply` into a scratch repo under `/private/tmp/ark-final-test-candidate-z0n2sQ/review-settings-scratch/` (source tree untouched, no commits/stash/checkout in `/private/tmp/ark-r18`); grep of registration-mutation sites; cordis `fiber.effect()` dispose semantics; schemastery `any()` resolver; `scripts/test-invariants.ts`; coverage reports `repair-settings-sealed-coverage/report/` and `repair-settings-coverage-fix-coverage/report/`.

## 9. Remediation required to flip the verdict

Make the invariant true rather than asserted: install the (pending) settlement **before** `commit` can execute any user-visible read — e.g., set `settlementRevision`/`settlement` synchronously adjacent to the bump (inside the same statement sequence as `bumpRevision`, before the `deepEqualJson(next, prev)` walk at :1091), so a re-entrant `settle()` from an accessor awaits the real outcome instead of fabricating success. Then the alternate arm becomes genuinely unreachable under the public API and the pragma's justification is accurate; alternatively remove the pragma and cover the arm with a regression test pinning the pending-settlement semantics. The other three pragmas need no change.

## 10. Exclusions

Out of scope and affirmed nowhere in this review: Connection-carrier behavior; GUI or LIVE behavior; FULL_GATE; Production readiness or deployment conclusions. Per the note's own scope statement ("they do not prove an installed Ark failure or GUI recovery"), this evidence base supports unit-level claims about `packages/settings/settings` only. No credentials were read, modified, or transmitted; no dependency, threshold, or timeout configuration was changed by the reviewed round; nothing in this review authorizes staging or deployment.

---

# Supplemental review: remediation re-verification (option 1)

**Supplemental Verdict: VERIFIED** — the remediated tree closes finding (d) as specified; the ternary alternate is now structurally unreachable, resolver consumption is single-owner and cannot cross revisions, the regression is faithful to my repro, retention-on-unchanged-repeat and the dispose paths are unchanged. Two residual fail-closed edges were found and are documented below as non-blocking (both narrower than the original finding, both pre-existing in exposure class, and the remediation strictly improves the worse one).

## S1. What changed (verified from artifacts, not the narrative)

Full src delta reconstructed from `repair-settings-coverage-fix-post/diff.patch` (pre state = the tree my first-round review verified) and diffed against current — exactly five hunks, all in `packages/settings/settings/src/index.ts`, matching the declared remediation:

1. `SettingsRegistration` gains `settlementResolver?: ((accepted: boolean) => void) | undefined` (index.ts:416-420, explicit `| undefined` — exactOptionalPropertyTypes-clean).
2. `bumpRevision` (:1066-1074): after `registration.revision += 1`, `Promise.withResolvers<boolean>()` binds `settlementRevision`/`settlement`/`settlementResolver` in the same synchronous statement block (:1068-1072).
3. `commit` equal+documentChanged branch (:1106-1111): resolves the pending binding `true` in place and clears the field (a raw-only revision has no callbacks — same semantics as the old `Promise.resolve(true)` rebinding, now as a resolution of the bound promise).
4. `commit` changed branch (:1139-1148): captures the resolver ONCE into a local, clears the field, wires `Promise.all(outcomes)` (or `true` when no watchers) into the captured resolver.
5. Comment-only: `settle()` JSDoc (:817-819) and the pragma justification text (:835) restated ("the bump itself binds each revision's settlement…").

The register disposer (quiescence timeout, late-settle delete, clean-dispose delete) is **not in the delta** — dispose paths untouched. `tests/settings.spec.ts` gains exactly one test (:847-883).

## S2. The arm is now genuinely unreachable — CONFIRMED

`registration.revision += 1` and the binding of `settlementRevision`/`settlement`/`settlementResolver` are adjacent synchronous statements with no user code between them (grep-verified: `settlementRevision` is assigned at exactly three sites — declaration :412, init :556-557 (`0`/`Promise.resolve(true)`, consistent), and the bump bind :1070; the commit sites no longer assign it). `bumpRevision` is the only increment site, immediately followed by the bind; both call sites (:986-987 write, :1025-1026 publish) invoke `commit` immediately after with no await in between. An accessor firing during `bumpRevision`'s own equality walk (:1067) runs *before* the increment and observes the previous consistent state. Therefore `settlementRevision === registration.revision` at every observable instant, and `settle()`'s ternary (:836-838) always takes the true arm. The pragma's corrected justification is now accurate.

## S3. Resolver consumption is single-owner and cannot cross revisions — CONFIRMED

- The changed branch captures into a local (:1143) and clears the field (:1144) synchronously; the async wire-up (:1148) invokes the **captured** resolver, whose closure target is the promise created at its own bump. A newer revision's rebinding can never redirect an older commit's resolution — the worst an interleaving can do is find the field empty (see S6 edge C), never resolve the wrong promise.
- The equal branch resolves and clears in place (:1109-1110). Because every bump is immediately followed by a commit that consumes-or-clears, the field can hold a live resolver only inside the bump→consume window; a re-entrant commit in that window always consumes/clears before returning, so the equal branch cannot resolve a newer binding either.
- Double-resolution is impossible: each consume clears the field, and each resolver belongs to exactly one promise.

## S4. Runtime re-verification of my original channel — CLOSED

`review-settings-probe-d-postfix` (rc=0, log sha256 `2e4f81ce5a84a594f03a36dfddc5c72118fed6708416a90150b9d93544c3f219`), Part A = my first-round public-API repro unchanged (accessor on `base`, read 3 lands inside commit's walk, failing watcher): re-entrant `settle(ns, 1)` now resolves **false** at t=95 — *after* `watcher-failing` at t=94, i.e. it awaited the real outcome — and posthoc settle is false. The early-true is gone; the true arm is taken and the caller observes the real result.

## S5. The regression is faithful — CONFIRMED

`tests/settings.spec.ts:847-883` reproduces my channel through the public API: accessor on `base` (`k` defined first, `zz` second — the same key-order + key-count subtlety my analysis identified as required for the walk to read the accessor post-bump), a sync-throwing watcher, one `update()`, asserting the re-entrant `settle(ns, 1)` resolves **false** (:878) and posthoc settle is false (:879). It fires `settle` on every accessor read with rejections contained, which additionally proves the pre-bump reads never produce a spurious resolution. 507 → 508 tests accounts for exactly this test.

## S6. Residual edges (non-blocking, fail-closed) — probed, not assumed

- **Edge B — throwing accessor in the walk** (`review-settings-probe-d-postfix` Part B): an accessor that throws inside commit's equality walk rejects `update()` and leaves the bump-bound settlement pending forever — `settle(ns, 1)` was still pending after 500 ms. Fail-closed (the pre-fix code returned a wrong `true` for the same input). The walk-throw position predates the remediation; the remediation only changes the observable from "wrong success" to "unresolved wait". If ever hardened: consume the binding with `false` when the walk throws.
- **Edge C — synchronous re-entrant publication from the walk** (`review-settings-probe-d-postfix-c2`, rc=0, log sha256 `9e46a8d2158edb898f10c446ef8ab656c7dde4df789ecd4a1ca64c377c324150`): an accessor that re-publishes a changed document inside the walk causes the older revision's commit to capture `undefined` (the re-entrant revision's commit cleared the field); its re-entrant `settle` remains pending after 600 ms while the newer revision settles normally (`revision 2 → true`). Not cross-revision *resolution* — an orphan. Strictly better than pre-fix, where the same input made the older commit **overwrite the newer revision's `settlementRevision`/`settlement` with its own outcomes** (cross-revision corruption); and any later `settle(ns, olderRev)` rejects with `SettingsConflictError` rather than hanging.

Both edges require user code inside the equality walk that throws or re-publishes — strictly narrower than the original finding, which needed only a benign accessor. Neither violates the settle-before-notification contract on any data-shaped path; I do not consider them grounds to withhold the verdict, but they are recorded for the maintainers.

## S7. Retention-on-unchanged-repeat and dispose — UNCHANGED, VERIFIED

- Unchanged-repeat: `bumpRevision` returns false without binding; the equal branch with `documentChanged === false` consumes nothing — the prior revision's settlement (pending or false) is retained. Covered by the suite's `does not erase pending owner settlement on an identical write/provider` (settings.spec.ts:885) and `binds document-event settlement to delayed owner failure through write/provider` (:807).
- Dispose: disposer code byte-identical (absent from the delta). Pending settlements resolve through watcher-outcome segments that remain in `pendingTails`, which the dispose drain awaits; the quiescence-timeout late-settle path is unaffected; `settle()`'s post-await disposal/conflict re-checks (:839-845) are untouched.

## S8. Seals and delta discipline for the remediation round — VERIFIED

- `repair-settings-settlement-fix-behavior` rc=0, 508/508, 18 files (settings 4 + llm 14; endpoint-transaction replay included). Log hash verified against receipt.
- `repair-settings-settlement-fix-coverage` rc=0 — 100% on all four metrics (426/426 stmts, 289/289 branches, 95/95 funcs, 367/367 lines); `coverage-final.json` re-parsed by me: **zero uncovered regions**.
- `repair-settings-settlement-fix-lint` and `-lint-r2` rc=0; `repair-settings-settlement-fix-typecheck` **rc=2 retained** (the exactOptionalPropertyTypes failure) with `-typecheck-r2` rc=0 — the failure evidence was kept, not overwritten.
- `repair-settings-settlement-fix-post` freeze at 2026-09-06T19:04:51Z, HEAD unchanged `84ae44c98c94bac19c29cd70516dc10a01af170b`. Manifest delta vs my verified `repair-settings-coverage-fix-post`: settings-scope = **exactly** `packages/settings/settings/src/index.ts` + `tests/settings.spec.ts`; docs/notes untouched. The six additional changed files (`integrations/jiuzhang/src/pack-runtime.mjs`, `integrations/jiuzhang/src/runtime-plan.mjs` + its test, three `packages/host/*` test files) and the untracked `build-r21-*`/`pack-r21-*` markers are the coordinator-declared out-of-scope build-gate drift repairs — none fall inside this item's scope, and none alter settings behavior or its gate configuration (vitest.config.ts / package.json / tsconfig unchanged).
- My own independent post-fix run: `review-settings-behavior-postfix` rc=0, 508/508, log sha256 `ff9800bcaeb498632f09ae38cd593321d265cee4ddaf880768a682200e4f53e2`.

## S9. Exclusions (unchanged)

Connection-carrier, GUI/LIVE, FULL_GATE, and Production conclusions remain out of scope and are affirmed nowhere in this review. The residual edges in S6 are unit-level observations about `packages/settings/settings` under adversarial accessor behavior; they prove nothing about installed Ark behavior, GUI recovery, or deployability.
