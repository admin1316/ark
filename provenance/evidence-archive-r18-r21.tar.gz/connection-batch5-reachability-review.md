# Independent Connection coverage reachability review

Model: GPT-5.6 Sol
Reasoning: High
Agent: 01a07373-f5d2-7c40-a036-a1ee7c4876a5
Fresh read-only context; closed after final verdict. Overall PARTIAL is not permission to edit production source.

# COVERAGE SOURCE FINDING: PARTIAL

冻结证据可信，新增测试方向有效，也没有发现新的生产行为缺陷；但当前仍有一个可由真实公开生命周期触发的未测竞争路径。其余缺口由已证明冗余的状态和不应为覆盖率删除的安全守卫组成，因此不能把本轮判为 100% coverage closure。

## 证据与范围

- 冻结命令记录为 36/36 tests PASS；`real_exit_code=1` 仅来自 `rpc-host.ts` 的 100% 阈值未满足。[receipt.json](</private/tmp/ark-final-test-candidate-z0n2sQ/coverage-connection-batch5-head/receipt.json>)
- 精确结果：statements `308/322`，branches `138/148`，functions `69/69`，lines `280/288`。[coverage-final.json](</private/tmp/ark-final-test-candidate-z0n2sQ/coverage-connection-batch5-head/report/coverage-final.json>)
- pre/post 的 HEAD、status、tracked、all-nonignored 指纹完全一致；8374 项 manifest、status、diff 也逐字节一致。[source-binding.json](</private/tmp/ark-final-test-candidate-z0n2sQ/coverage-connection-batch5-head/source-binding.json>)
- 两个冻结副本和当前 canonical 文件均一致：
  - `rpc-host.ts`: `8f563d75…e802`
  - `host-connection.spec.ts`: `be096d4a…721e`
- 因而本 batch 确实只有测试/证据运行，没有生产源码改动。
- 本次审查没有运行测试或构建，也没有写文件、改 Git、联网或使用凭据。

## 14 statements / 10 branch paths 的逐项归类

| 位置 | 当前缺口 | 分类 | 判断 |
|---|---:|---|---|
| [rpc-host.ts:240](</private/tmp/ark-r18/packages/host/connection/src/rpc-host.ts:240>) | 1 stmt / 1 branch | genuinely dead/redundant | Cordis effect disposer是 single-shot；并发 owner teardown 通过其 in-flight inertia 汇合，公开重复 `remove()` 又由外层 `result` 汇合。内层 `disposal` 状态没有合法第二次入口。 |
| [rpc-host.ts:255](</private/tmp/ark-r18/packages/host/connection/src/rpc-host.ts:255>) | 1 stmt / 2 branches | safety invariant to retain | Cordis 会直接调用 effect cleanup，同步 throw 可以越过其 disposer。这里把 Error/非 Error 同步异常转换为稳定的 rejected Promise，维护公开 `() => Promise<void>` 契约。替换 `owner.effect` 才能强行覆盖，属于无效 subject replacement。 |
| [rpc-host.ts:458](</private/tmp/ark-r18/packages/host/connection/src/rpc-host.ts:458>) + [rpc-host.ts:516](</private/tmp/ark-r18/packages/host/connection/src/rpc-host.ts:516>) | 2 stmt / 2 branches | reachable missing test | 真实的 producer-error/request-abort 微任务竞争可以第二次进入 `beginTerminal()`。这是唯一应补的真实覆盖路径。 |
| [rpc-host.ts:476](</private/tmp/ark-r18/packages/host/connection/src/rpc-host.ts:476>)–478 | 3 stmt / 2 branches | genuinely dead/redundant | 原生 `reader.cancel()` 在等待底层 cancel 结果前已关闭/错误化流并清空 pending reads；无论 cancel resolve/reject，之后 `releaseLock()` 都没有合法 TypeError 条件。 |
| [rpc-host.ts:488](</private/tmp/ark-r18/packages/host/connection/src/rpc-host.ts:488>) | 1 stmt / 1 branch | safety invariant to retain | Abort listener 是 `{once:true}`，且其他 terminal 入口会移除它；当前无法诚实触发 false 分支，但此 guard 维持统一的 terminal 幂等边界。 |
| [rpc-host.ts:508](</private/tmp/ark-r18/packages/host/connection/src/rpc-host.ts:508>)–509 | 2 stmt | genuinely dead/redundant | `reader.read()` 已返回 `done`，不存在 pending read；line 501 又排除了 cancel/abort 已获胜的情况，原生 `releaseLock()` 和 `controller.close()` 均不会在受支持状态下抛出。 |
| [rpc-host.ts:521](</private/tmp/ark-r18/packages/host/connection/src/rpc-host.ts:521>)–522 | 2 stmt | genuinely dead/redundant | `reader.read()` 已拒绝并移除其 pending request；`beginTerminal()` 已取得唯一终态，原生 `releaseLock()`/`controller.error()` 无可达同步失败。 |
| [rpc-host.ts:528](</private/tmp/ark-r18/packages/host/connection/src/rpc-host.ts:528>) | 1 stmt / 1 branch | safety invariant to retain | 原生 ReadableStream 每次终态只调用一次 underlying `cancel`；重复 reader cancel 不会再次进入该 callback。保留 guard，禁止通过直接调用 callback 或改 `terminal` 来覆盖。 |
| [rpc-host.ts:533](</private/tmp/ark-r18/packages/host/connection/src/rpc-host.ts:533>) | 1 stmt / 1 branch | genuinely dead/redundant | line 322 已在 handler await 后检查 abort；从该检查到 listener 注册的普通 body 路径没有 await，JavaScript run-to-completion 下不存在合法失窗。 |

核算正好为：

- dead/redundant：9 statements、4 branch paths
- reachable missing test：2 statements、2 branch paths
- safety invariants：3 statements、4 branch paths

## 唯一真实补测序列

通过公开 `downloads.handle` 和 `createSharedFetchHandler`：

1. handler 返回原生 `Response(new ReadableStream(...))`，保存 producer controller。
2. 使用真实 `Request(..., {signal: AbortController.signal})` 发起下载，并开始 `response.text()`，使 `reader.read()` pending。
3. 同一同步段先调用 `producerController.error(producerFailure)`，紧接着调用 request controller 的 `abort(requestReason)`，然后才让出微任务。
4. 验证响应 body 以 `requestReason` 失败；producer 的既有错误只作为 cancellation/quiescence 失败由公开 `remove()` 拒绝；终态和 cancel 各发生一次。

这会诚实覆盖 line 516 的 duplicate guard，同时覆盖 line 458；无需访问或修改 private set/boolean，也无需伪造原生 reader 方法。

当前 line 322 的 handler-await 后 abort 检查，以及 [line 501](</private/tmp/ark-r18/packages/host/connection/src/rpc-host.ts:501>) 的 `reader.read()` 后竞争检查已经有执行证据，必须保留。

## 独立确认的最小安全清理

仅对受支持的原生 `Response`/ReadableStream 和当前 Cordis 契约，以下清理可认定为 behavior-preserving：

- 删除 line 238–246 的内层 `disposal` memoization，仅直接返回现有 `Promise.all(...).then(...)`；保留外层 `result` promise。
- 展平 line 473–480、504–510、517–523 中不可达的 `releaseLock`/controller 异常包装；必须保留 `reader.cancel()` 的合法 rejection 捕获与 `lifetime.fail`。
- 删除 line 533 的重复 abort 检查。
- 不删除 line 255、488、528，也不移动 Node assert、增加 ignore/exclude、修改阈值/超时/重试，或新增测试工厂/导出。

这些清理尚未实施或验证。新增的真实竞争测试也尚不存在，所以整体结论保持 **PARTIAL**。Ping/Wiki/endpoint repairs、NativeEvents ignore、FULL_GATE、构建与产品行为均未审查或授权。



