# Pi-ai initialization source-finding review

Model: GPT-5.6 Sol; reasoning: High; fresh read-only context.
Agent: 01a07324-da47-7e40-9247-12d021a3e46d.

# COVERAGE SOURCE FINDING VERIFIED

Scoped verdict: the three RC1 records are redundant/dead under the current production lifecycle. Exact behavior-preserving cleanup is authorized only in [llm-pi-ai/src/index.ts](/private/tmp/ark-r18/packages/llm/llm-pi-ai/src/index.ts:155).

Evidence:

- Receipt: 13 files and 334 assertions passed. Exit code `1` is solely the coverage gate: lines 100%, statements 97.7%, branches 96%, functions 95.45%. The initializer callback at line 155 ran zero times; the true branches at lines 389 and 395 also ran zero times.
- Line 155: `requested()` is read only by `onChange`. [installSettingsSection](/private/tmp/ark-r18/packages/settings/settings/src/index.ts:1271) calls `setSource` before every matching attach/detach `onChange`; live changes reuse the already-installed `scope.get` thunk. With no settings service, neither callback runs and `accepted = config` remains authoritative. Replace with:
  ```ts
  let requested: () => Config
  ```
- Line 389: `registration === undefined` is legitimate only for a dormant generation with no successfully registered routes. If the last accepted generation has nonempty routes, either initial installation or an earlier successful update necessarily assigned the handle. A first-route collision leaves both `registration` undefined and `previousRoutes` empty. Remove only the impossible resurrection branch while retaining the reachable guard:
  ```ts
  if (registration !== undefined) registration.replace(previousRoutes)
  ```
- Line 395: the configurable-provider directory is registered synchronously before `installSettingsSection` installs any hook. After successful `apply`, its handle cannot be undefined. Initialize it once:
  ```ts
  const initialDirectory = directoryEntries(allProfiles())
  const directory = ctx.llm.registerConfigurableProviders(initialDirectory)
  let directoryFacts: unknown = initialDirectory
  ```
  Thereafter both normal updates and rollback call `directory.replace(...)`; remove the initial `ensureDirectory()` call and both undefined/re-register branches.

Counterexample search found no authorized path reaching the removed states:

- Adapter and directory candidate validation occurs before mutation.
- Ordinary synchronous topology-listener exceptions are contained.
- Settings watchers are serialized asynchronously; attach and detach explicitly establish the source first.
- Same-stack lifecycle disposal never clears either local handle back to `undefined`.
- A directory failure after an adapter swap occurs only after the adapter handle has been assigned.
- The special post-commit `INVARIANT` exception is outside this verdict. The NativeEvents invariant exception remains untouched and unadjudicated.

Exact permitted scope: only the three reductions above plus directly necessary comments/types in this file. No settings-helper, LLM-registry, NativeEvents, test, dependency, configuration, public-contract, error-handling, or runtime-safety changes.

Validation required after implementation:

1. Fresh independent read-only review of the exact patch.
2. Targeted typecheck/lint and the full pi-ai module suite.
3. Per-file 100% statements, branches, functions, and lines—without ignores, exclusions, seams, or test-private exports.
4. Preserve behavioral coverage for dormant first-route collision/recovery, existing-route rollback, directory-collision rollback, settings attach/live/detach, and disposal.
5. Run the authorized full gate afterward; any gate failure stops advancement.

No files were edited, generated, tested, built, launched, or mutated during this review.



