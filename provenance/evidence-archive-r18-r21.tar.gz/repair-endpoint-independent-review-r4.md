# Endpoint Generation independent review — round 4

Model: GPT-5.6 Sol; reasoning: High; fresh strictly read-only reviewer Avicenna 01a07503-d7c4-7a03-af9a-9f85f0493b63. Verbatim completed final:

REVISE — STOP

决定性反例有效，不是私有状态破坏或无效 provider fixture。

- 根因：R4 仅在 `claimJournal` 时核验事务归属；认领结束后，凭据读取、写入、settings 提交与 journal 更新不共享完整生命周期所有权。[remote.ts](/private/tmp/ark-r18/packages/llm/llm/src/remote.ts:466)
- 合法竞态：A1 已认领并在公开异步 `credentials.resolve()` 暂停；A2 完成同一事务，随后 B 完成新事务并写入 `fixture-B`；A1 根据先前读取结果无条件执行 `set(..., fixture-A)`。[remote.ts](/private/tmp/ark-r18/packages/llm/llm/src/remote.ts:1121)
- 归属检测发生在破坏之后：后续 `writeJournal` CAS 能发现 journal 已属于 B 并返回 `provider-transaction-in-doubt`，但 B 的凭据已被 A1 覆盖。[remote.ts](/private/tmp/ark-r18/packages/llm/llm/src/remote.ts:1294)
- fixture 有效：`CredentialProvider.resolve` 是公开异步读取，契约未保证它与 `set` 或 `modifyRecord` 原子化；Memory provider 正常实现该契约，测试只在公开方法边界安排并发时序。[credentials/index.ts](/private/tmp/ark-r18/packages/credentials/credentials/src/index.ts:197) [memory.ts](/private/tmp/ark-r18/packages/credentials/credentials/tests/memory.ts:26) 实际 Local provider 的 resolve、凭据写入和 journal RMW 同样是分开的异步操作。[credentials-local/index.ts](/private/tmp/ark-r18/packages/credentials/credentials-local/src/index.ts:742)
- 公开可达：`llm/mutateProvider` 直接进入该链路，没有包围整个事务的串行化 owner。[llm/index.ts](/private/tmp/ark-r18/packages/llm/llm/src/index.ts:164)

既有证据核验：

- 当前失败测试：[remote-coverage.spec.ts](/private/tmp/ark-r18/packages/llm/llm/tests/remote-coverage.spec.ts:1359)。
- 日志 SHA-256 `efea7722…ceb83cf8` 匹配；真实结果为 343 PASS / 1 FAIL、RC 1，实际 `fixture-A`，期望 `fixture-B`；coverage RC 1，100% 阈值未变。
- `repair-endpoint-r4-final.diff` SHA-256 `728c39e…538db2482` 匹配。
- 物理源为 `/private/tmp/ark-r18`，HEAD `84ae44c98c94bac19c29cd70516dc10a01af170b`。
- bounded test 前后 full manifest 完全相同；当前五个文件哈希均匹配 post manifest，R4-pre→current-post 仅这五个文件变化。
- 早先 343/343 发生在新增该失败回归之前，不是当前 green。

R4 的 original-snapshot/shared-admission 修复了 pre-claim 与 outer-resume 身份丢失，但未建立从 claim 到最终 receipt 的完整所有权生命周期。Group 3 仍为当前红色，不能进入后续 gate、build、candidate 或 LIVE。

最小下一修复范围：在权威 LLM transaction owner 中引入一个同时覆盖 mutate/resume、claim、credential side effect、settings commit 和终态 journal 的 provider-scoped 排他或 fencing 机制；或者提供受当前 journal ownership token 约束的条件凭据写入。继续增加 claim 前后零散检查不足以修复该竞态。

本次仅做静态读取、哈希、diff、manifest 与既有日志核验；未执行测试或任何禁止操作。
