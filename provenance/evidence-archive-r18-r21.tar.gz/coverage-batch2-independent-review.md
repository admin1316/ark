# Independent final review — pi cleanup and separate Pong diagnosis

Model: GPT-5.6 Sol
Reasoning: High
Agent: 01a07330-b99a-76b2-84c8-73f430baf3ee
Fresh read-only context; agent closed after this final verdict.

## Output 1 — pi-ai initializer cleanup

**Scope-local verdict: VERIFIED.** No actionable correctness or simplification finding.

- `requested` is assigned by `setSource` before every attach/detach `onChange`; live watchers reuse that established source. With no Settings service, `onChange` never runs. The uninitialized thunk at [index.ts:155](/private/tmp/ark-r18/packages/llm/llm-pi-ai/src/index.ts:155) is therefore safe.
- Initial directory registration remains synchronous, in the same lifecycle position, with the same entries and failure behavior at [index.ts:274](/private/tmp/ark-r18/packages/llm/llm-pi-ai/src/index.ts:274).
- The rollback guard at [index.ts:384](/private/tmp/ark-r18/packages/llm/llm-pi-ai/src/index.ts:384) preserves every reachable state: an accepted nonempty route generation necessarily owns a registration handle; a failed first activation from dormancy has no previous routes and correctly performs no adapter restoration.
- The dynamic tests cover dormant collision/recovery and existing-registration rollback paths. Broader credential tests predate the source cleanup in the supplied snapshots and remain test-only.
- Snapshot comparison: batch-pre → source-pre changed only the three authorized test files; source-pre → final changed only `packages/llm/llm-pi-ai/src/index.ts`. Package manifest, tsconfig, lockfile, Settings implementation, and LLM registry sources stayed byte-identical. NativeEvents also stayed byte-identical within this phase.
- No coverage ignores, test skips/only markers, retries, configuration changes, dependency changes, or production scope creep appear in the cleanup diff.
- Current source SHA-256 `912428cb…d434` and dynamic-test SHA-256 `34bd6ff2…69d` match the post manifest. Git blobs `221a835…` and `ef3d838…` match the diff’s resulting blobs; reverse applicability check passed.
- Independently recomputed diff SHA-256 is `e635a8b7…abdaa`; recorded log hashes match. The validation records real RC `0` for 13 files / 334 tests, package `tsc --noEmit`, strict lint, and `git diff --check`.
- Coverage JSON contains exactly the canonical source key `/private/tmp/ark-r18/packages/llm/llm-pi-ai/src/index.ts`: 125/125 statements, 44/44 branches, 21/21 functions, 113/113 lines.

This verifies only the pi-ai cleanup scope. `FULL_GATE` was not run; there is no build, candidate, current-app, or LIVE closure claim.

## Output 2 — WebSocket Pong diagnosis

**Diagnosis: CONFIRMED.**

The real-Pong test is exposing a production defect, not a test defect:

1. `ws@8.21.0` forwards `WebSocket.ping()`’s callback to `net.Socket.write()`.
2. Node’s writable callback contract permits `Error | null | undefined`; successful real writes can supply `null`.
3. [websocket-downlink.ts:185](/private/tmp/ark-r18/packages/host/connection/src/websocket-downlink.ts:185) declares only `Error | undefined`, then [line 186](/private/tmp/ark-r18/packages/host/connection/src/websocket-downlink.ts:186) treats `null !== undefined` as failure.
4. `failSocket(null)` consequently produces the observed `EVENT_STREAM_FAILED` with `message: "null"` and closes the socket before the test’s later injected transport failure.

The focused diagnostic’s RC is genuinely `1`; recomputed log SHA-256 matches `bbce96eb…d19c`. The test uses a real client/server WebSocket pair, receives a real Pong, and its idle event source cannot independently emit that null failure.

Minimal proposed future scope: one nullish-success correction to the ping callback handling in `websocket-downlink.ts`, retaining the existing real-Pong plus injected-`Error` regression test. No NativeEvents changes; its ring assertion and coverage exception remain unmodified and unauthorized.

No files were edited or generated, and no tests, build, full gate, network, candidate, LIVE, credential, or Git mutation was performed during this review.

